
#include <iostream>
#include <limits>
#include <memory>
#include <stack>
#include <sstream>
#include <tr1/memory>

#include <cstdlib>

#define notYetImplemented()                          \
  do {                                               \
    std::cerr << "Not yet implemented" << std::endl; \
    abort();                                         \
  } while(0)

#define unreachable()                        \
  do {                                       \
    std::cerr << "Unreachable" << std::endl; \
    abort();                                 \
  } while(0)

namespace plp {

//
// LazyTraits<Ty> implementation.
//

// We want to build a framework for handling lazy expressions. We need a trait
// to require some constraints on the elements to be lazily evaluated.
// 
// Specialization must provide the following members:
//
// static Ty add(const Ty &, const Ty &):
//   strictly adds two elements
//
// The trait is not strictly necessary -- e.g. for many types "add" is just
// "operator+" --, but it helps identifying features a type should provide
// in order to be part of a lazily-evaluated expression.
template <typename Ty>
struct LazyTraits;

// A lazy expression is defined recursively. As with "BinaryTree<Ty>", the
// "LazyExpr" class is just an handler for the real expression tree.
template <typename Ty>
class LazyExpr {
private:
  // Every component of a lazy expression must derived from this class. It
  // provides functionalities to evaluate an expression and cache the computed
  // value.
  class Expr {
  protected:
    Expr(Ty *value = NULL) : value(value) { }

  public:
    // This member function returns the expression value. Expression evaluation
    // is forced, if never done.
    Ty &eval() {
      if(!value.get())
        value.reset(forceEval());

      return *value.get();
    }

    // This member functions must be implemented by sub-classes to evaluate the
    // expression. Since at compile-time we do not know the shape of the
    // expression, binding of "forceEval" must be performed at runtime -- it
    // must be "virtual".
    virtual Ty *forceEval() = 0;

  private:
    std::auto_ptr<Ty> value;
  };

  // This expression represents the sum between two homogeneous expressions.
  // Traits are used to explicitly require the template parameter to implement
  // addition.
  class AddExpr : public Expr {
  private:
    AddExpr(Expr &exprA, Expr &exprB) : exprA(&exprA),
                                        exprB(&exprB) { }

  public:
    virtual Ty *forceEval() {
      return new Ty(LazyTraits<Ty>::add(exprA->eval(), exprB->eval()));
    }

  private:
    // Since expressions can be shared, it is not possible using "std::auto_ptr"
    // to manage the life-time of sub-expressions composing this expression. We
    // have to use another technique -- reference counting -- to count how many
    // times an expression is used.
    //
    // Each expression referenced through a "std::tr1::shared_ptr" has an
    // associated counter. At reference time, the counter is incremented.
    //
    // When expression is no longer referenced -- e.g. the destructor of
    // "std::tr1::shared_ptr" is called -- the counter is decremented. When it
    // reaches zero, pointed object is no longer referenced, and thus it can be
    // deleted.
    std::tr1::shared_ptr<Expr> exprA;
    std::tr1::shared_ptr<Expr> exprB;

    friend class LazyExpr;
  };

  // This class represents the leaves of the expression. Obviously, it is not
  // possible forcing the evaluation of that kind of expression, because it is
  // built starting from an already evaluated expression.
  class AtomExpr : public Expr {
  private:
    AtomExpr(const Ty &expr) : Expr(new Ty(expr)) { }

  public:
    virtual Ty *forceEval() {
      unreachable();
    }

  private:
    friend class LazyExpr;
  };

public:
  static LazyExpr createAdd(const LazyExpr &exprA, const LazyExpr &exprB) {
    LazyExpr &noConstA = const_cast<LazyExpr &>(exprA),
             &noConstB = const_cast<LazyExpr &>(exprB);

    return LazyExpr(new AddExpr(*noConstA.expr, *noConstB.expr));
  }

  static LazyExpr createAtom(const Ty &expr) {
    return LazyExpr(new AtomExpr(expr));
  }

public:
  LazyExpr(const LazyExpr &that) {
    notYetImplemented();
  }

  const LazyExpr &operator=(const LazyExpr &that) {
    notYetImplemented();
  }

private:
  LazyExpr(Expr *expr) : expr(expr) { }

public:
  // This member function allows to define a casting operator from
  // "LazyExpr<Ty>" to "Ty &". This enable using C++ casting operators with
  // "LazyExpr<Ty>" values. Moreover, whenever the C++ compiler needs to convert
  // a "LazyExpr<Ty>" to a "Ty &", this member function is called.
  //
  // Please notice that the cast simply enforces expression evaluation.
  operator Ty &() {
    return expr->eval();
  }

private:
  std::tr1::shared_ptr<Expr> expr;
};

// Overloading "operator+" for "LazyExpr<Ty>" allows to provide a nice interface
// for performing addition between lazy expressions.
template <typename Ty>
LazyExpr<Ty> operator+(const LazyExpr<Ty> &exprA, const LazyExpr<Ty> &exprB) {
  return LazyExpr<Ty>::createAdd(exprA, exprB);
}

// This function simply allows building a lazy expression for a given elemental
// value. It is the starting point for defining a lazy expression.
template <typename Ty> inline
LazyExpr<Ty> lazy(const Ty &expr) {
  return LazyExpr<Ty>::createAtom(expr);
}

//
// RandomTraits<Ty> implementation.
//

// The "RandomTraits" trait is used to generate sequences of random values.
// Specialization must provide an input iterator "random_iterator" used to walk
// the sequence of random values. Moreover the following static member functions
// must be provided:
//
// static random_iterator random_begin(unsigned samples = X):
//   get an iterator to the start of a sequence with "samples" random elements
//
// static random_iterator random_end():
//   get an iterator to the end of a random sequence
template <typename Ty>
struct RandomTraits;

// Specialization of "RandomTraits" for "unsigned type".
template <>
struct RandomTraits<unsigned> {
  // Random values are generated on-flight. The state of the iterator is
  // composed by:
  //
  // unsigned cur:
  //   current random element
  // unsigned last:
  //   number of remaining elements
  //
  // To advance the iterator, just generates a new random element, and decrement
  // the number of remaining elements.
  class random_iterator {
  public:
    // The default constructor is public. This allows to construct an iterator
    // without any arguments -- usually the iterator representing the end of the
    // sequence -- and thus declaring variables of type "random_iterator":
    //
    // RandomTraits<unsigned>::random_iterator i;
    //
    // The declaration constructs a legal iterator -- "i" references the end of
    // any sequence.
    random_iterator() : cur(0),
                        last(0),
                        mod(0) { }

  private:
    // This constructor is private. In this way we force building iterators only
    // using the static member functions.
    random_iterator(unsigned samples) : cur(0),
                                        last(samples),
                                        mod(samples) {
      advance();
    }

  public:
    // Given two iterators, "i" and "j", equality holds if:
    //
    // "i" and "j" are different from the end the sequence:
    //   both reference the same element in the sequence -- the same random
    //   number -- and they have still to generate the same number of elements
    //
    // "i" and "j" represents the end of the sequence:
    //   both have no more elements to generate, no matter which elements have
    //   been generate up to now
    bool operator==(const random_iterator &that) const {
      return (cur == that.cur && last == that.last) ||
             (last == 0 && that.last == 0);
    }

    bool operator!=(const random_iterator &that) const {
      return !(*this == that);
    }

    random_iterator &operator++() {
      advance(); return *this;
    }

    random_iterator operator++(int ign) {
      random_iterator ret(*this); advance(); return ret;
    }

    const unsigned &operator*() const {
      return cur;
    }

  private:
    void advance() {
      if(!last)
        return;

      // Numbers are generated modulo "mod" just to print them nicely.
      cur = std::rand() % mod;
      --last;
    }

  private:
    unsigned cur;
    unsigned last;

    unsigned mod;

    friend class RandomTraits<unsigned>;
  };

  static random_iterator random_begin(unsigned samples = 16) {
    return random_iterator(samples);
  }

  static random_iterator random_end() {
    return random_iterator();
  }
};

//
// IndexTraits<Ty> implementation.
//

// We are going to build a binary tree, thus we need an index for each element
// in the tree. Specialization of this traits must provide:
//
// static unsigned index(const Ty&):
//   get the index associated to the given element.
//
// The index is mainly used to identify the element inside the tree.
template <typename Ty>
struct IndexTraits;

// Specialization of "IndexTraits" for the "unsigned" type. The index is the
// element itself.
template <>
struct IndexTraits<unsigned> {
  static unsigned index(const unsigned &elt) {
    return elt;
  }
};

//
// BinaryTree<Ty> implementation.
//

// A parametric binary tree. Tree representation is split into two classes:
//
// BinaryTree:
//   implements the tree high level operations, such as inserting elements.
//   Moreover, it hides implementation details, like representing empty trees
//   with a "NULL" pointer
//
// BinaryTree::Node:
//   represents nodes in the tree. It is the fundamental block used to build
//   pointer-based trees
//
// Moreover, The "BinaryTree" class defines node and edge iterators.
template <typename Ty>
class BinaryTree {
public:
  // A node is represented using a straightforward implementation:
  //
  // elt:
  //   stored element
  //
  // left:
  //   pointer to left child
  //
  // right:
  //   pointer to right child
  //
  // As usual, if both pointers are "NULL", the node is a leaf.
  //
  // Please notice that the node is copyable wit deep copy semantic. This
  // implies a nodes is in charge of managing the lifetime of its children.
  class Node {
  public:
    Node(const Ty &elt) : elt(elt) { }

    Node(const Node &that) : elt(that.elt) {
      if(that.hasLeft())
        setLeft(new Node(*that.getLeft()));

      if(that.hasRight())
        setRight(new Node(*that.getRight()));
    }

    const Node &operator=(const Node &that) {
      if(this == &that)
        return;

      elt = that.elt;

      if(that.hasLeft())
        setLeft(new Node(*that.getLeft()));

      if(right.hasRight())
        setRight(new Node(*that.getRight()));
    }

  public:
    // Classical insertion algorithm is based on recursion. While recursion is a
    // nice feature, it needs special support to be efficiently compiled -- i.e.
    // code exploiting recursion with good performance is often coded in a
    // function language.
    //
    // In the imperative world, a recursive algorithm must be translated into a
    // iterative one, in order to avoid cost related to call stack management.
    //
    // The "IndexTraits" trait is used to get the index of an element. Pure
    // OO-based implementations, often rely on virtual functions. Using traits
    // it is possible writing readable code without losing performance.
    void insert(const Ty &elt) {
      unsigned idx = IndexTraits<Ty>::index(elt);
      Node *cur = this;

      while(cur) {
        unsigned curIdx = IndexTraits<Ty>::index(cur->elt);

        if(idx == cur->elt)
          cur = NULL;

        else if(idx < curIdx && !cur->hasLeft()) {
          cur->setLeft(new Node(elt));
          cur = NULL;
        }

        else if(idx > curIdx && !cur->hasRight()) {
          cur->setRight(new Node(elt));
          cur = NULL;
        }

        else if(idx < curIdx && cur->hasLeft())
          cur = cur->getLeft();

        else if(idx > curIdx  && cur->hasRight())
          cur = cur->getRight();

        else
          unreachable();
      }
    }

  public:
    Ty &getElt() {
      return elt;
    }

    const Ty &getElt() const {
      return elt;
    }

    Node *getLeft() const {
      return left.get();
    }

    Node *getRight() const {
      return right.get();
    }

    bool hasLeft() const {
      return left.get();
    }

    bool hasRight() const {
      return right.get();
    }

    bool isLeft(const Node &node) const {
      return &node == left.get();
    }

    bool isRight(const Node &node) const {
      return &node == right.get();
    }

    unsigned getIndex() const {
      return IndexTraits<Ty>::index(elt);
    }

    bool isLeaf() const {
      return !left && !right;
    }

protected:
    void setLeft(Node *node) {
      left.reset(node);
    }

    void setRight(Node *node) {
      right.reset(node);
    }

  private:
    Ty elt;

    // Since the node must manage the life-time of its children, we have to
    // delete them when the node is destroyed. This is usually done in the
    // destructor:
    //
    // ~Node {
    //   if(left)
    //     delete left;
    //
    //   if(right)
    //     delete right;
    // }
    //
    // In alternative we can use "std::auto_ptr". It is an object acting like a
    // pointer. The difference is that is owns the pointed object, so it is in
    // charge of managing its lifetime, that is "delete" is automatically called
    // on pointed object when the "std::auto_ptr" is destroyed.
    std::auto_ptr<Node> left;
    std::auto_ptr<Node> right;
  };

  // We are going to provide different kind of iterators to tree nodes:
  // pre-order, in-order, and post-order. The only difference between them is
  // how the tree is traversed.
  //
  // Like insertion, also traversal is defined using a recursive algorithm. You
  // can express it iteratively exploiting a support stack. The difference
  // between the different visits is just how the support stack is used.
  //
  // If we assume that current element in the iteration is stack top, we can
  // factorize some code. This class defines functionalities shared by all
  // iterators implementing a certain type of visit. Basically it provides
  // storage for the support stack and member functions implementing iterator's
  // syntactic sugar.
  //
  // Advancing the iterator depends on the type of visit, so the "advance"
  // member function must be implemented by subclasses of "ConstNodeIterator".
  // Pure OO-base implementation often used virtual function to correctly route
  // the "advance" call.
  //
  // Templates allow to transform a virtual call into a normal call. Just
  // add a template parameter -- "IterTy" -- identifying the type of visit. It
  // must be a sub-class of "ConstNodeIterator". That template parameter is used
  // to cast "this" to "IterTy" before calling the "advance" member function.
  // This allows to call the right implementation.
  template <typename IterTy>
  class ConstNodeIterator {
  protected:
    ConstNodeIterator() { }

  public:
    bool operator==(const IterTy &that) {
      return stack == that.stack;
    }

    bool operator!=(const IterTy &that) {
      return !(*this == that);
    }

    const Node &operator*() const {
      return *stack.top();
    }

    const Node *operator->() const {
      return stack.top();
    }

    IterTy &operator++() {
      IterTy &my = static_cast<IterTy &>(*this);

      my.advance(); return my;
    }

    IterTy operator++(int ign) {
      IterTy &my = static_cast<IterTy &>(*this);

      IterTy ret(my); my.advance(); return ret;
    }

  protected:
    std::stack<const Node *> stack;
  };

  // An iterative pre-order visit exploits the support stack in this way:
  //
  // 1 - remove visited elements
  // 2 - push right child -- if it exists
  // 3 - push left child -- if it exists
  //
  // The visit is extremely efficient -- advancing the iterators has a
  // constant-time complexity.
  class const_pre_order_node_iterator :
    public ConstNodeIterator<const_pre_order_node_iterator> {
  private:
    const_pre_order_node_iterator(const Node *root) {
      if(!root)
        return;

      stack.push(root);
    }

  public:
    const_pre_order_node_iterator() { }

  private:
    void advance() {
      if(stack.empty())
        return;

      const Node *top = stack.top();

      stack.pop();

      if(top->hasRight())
        stack.push(top->getRight());

      if(top->hasLeft())
        stack.push(top->getLeft());
    }

  private:
    using ConstNodeIterator<const_pre_order_node_iterator>::stack;

    friend class BinaryTree;
  };

  // An iterative in-order visit exploits the support stack in this way:
  //
  // 1 - remove visited element
  // 2 - push right child -- if exists
  // 3 - push all nodes found in the path leading from the right child to right
  //     child leftmost descendant, moving only along left children -- if such
  //     path exists
  //
  // The complexity of iterator advancing is not constant -- it depends on how
  // many nodes are found at step (3).
  class const_in_order_node_iterator :
    public ConstNodeIterator<const_in_order_node_iterator> {
  private:
    const_in_order_node_iterator(const Node *root) {
      advance(root);
    }

  public:
    const_in_order_node_iterator() { }

  private:
    void advance() {
      if(stack.empty())
        return;

      const Node *top = stack.top();

      stack.pop();

      if(top->hasRight())
        advance(top->getRight());
    }

    void advance(const Node *start) {
      const Node *cur = start;

      while(cur) {
        stack.push(cur);

        if(cur->hasLeft())
          cur = cur->getLeft();

        else
          cur = NULL;
      }
    }

  private:
    using ConstNodeIterator<const_in_order_node_iterator>::stack;

    friend class BinaryTree;
  };

  // An iterative post-order visit exploits the support stack in this way:
  //
  // 1 - remove visited element
  // 2 - if the stack is empty, the removed node was the root of the tree -- no
  //     more nodes to visit
  // 3 - let "top" the top of the stack after step (1). If the remove node was
  //     the left child of "top" and "top" has a right child, push all nodes
  //     found walking the path starting from "top" right child and ending at
  //     its leftmost children
  //
  // The complexity of iterator advancing depends on how many nodes are found in
  // step (3).
  class const_post_order_node_iterator :
    public ConstNodeIterator<const_post_order_node_iterator> {
  private:
    const_post_order_node_iterator(const Node *root) {
      advance(root);
    }

  public:
    const_post_order_node_iterator() { }

  private:
    void advance() {
      if(stack.empty())
        return;

      const Node *prev = stack.top();

      stack.pop();

      if(stack.empty())
        return;

      const Node *top = stack.top();

      if(top->hasRight() && top->isLeft(*prev))
        advance(top->getRight());
    }

    void advance(const Node *start) {
      const Node *cur = start;

      while(cur) {
        stack.push(cur);

        if(cur->hasLeft())
          cur = cur->getLeft();

        else if(cur->hasRight())
          cur = cur->getRight();

        else
          cur = NULL;
      }
    }

  private:
    using ConstNodeIterator<const_post_order_node_iterator>::stack;

    friend class BinaryTree;
  };

  // This is a classical usage of templates. Tree edges can be visited using
  // normal and const iterators. Normal iterators allows to edit the referenced
  // objects, while const iterators allows accessing to only const members of
  // referenced object.
  //
  // Despite the type of iterator, the referenced object is still and edge. What
  // changes is whether it is an "Edge" or a "const Edge". Here we define a
  // template for a generic edge.
  template <typename NodeTy>
  class EdgeBase {
  public:
    EdgeBase(NodeTy &from, NodeTy &to) : from(&from), to(&to) { }

    EdgeBase() : from(NULL), to(NULL) { }

  public:
    bool operator==(const EdgeBase &that) const {
      return from == to;
    }

    bool operator!=(const EdgeBase &that) const {
      return !(*this == that);
    }

  public:
    NodeTy &getFrom() const {
      return *from;
    }

    NodeTy &getTo() const {
      return *to;
    }

  private:
    NodeTy *from;
    NodeTy *to;
  };

  // This typedef defines a "ConstEdge", that is an edge referencing two nodes
  // that cannot be edited.
  typedef EdgeBase<const Node> ConstEdge;

  // Edges iteration is performed using a pre-order visit of edges.
  class const_edge_iterator {
  private:
    const_edge_iterator(const Node *root) {
      if(!root)
        return;

      if(root->hasRight())
        stack.push(ConstEdge(*root, *root->getRight()));

      if(root->hasLeft())
        stack.push(ConstEdge(*root, *root->getLeft()));
    }

  public:
    const_edge_iterator() { }

  public:
    bool operator==(const const_edge_iterator &that) {
      return stack == that.stack;
    }

    bool operator!=(const const_edge_iterator &that) {
      return !(*this == that);
    }

    const ConstEdge &operator*() const {
      return stack.top();
    }

    const ConstEdge *operator->() const {
      return &stack.top();
    }

    const_edge_iterator &operator++() {
      advance(); return *this;
    }

    const_edge_iterator operator++(int ign) {
      const_edge_iterator ret(*this); advance(); return ret;
    }

  private:
    void advance() {
      if(stack.empty())
        return;

      ConstEdge top = stack.top();

      const Node &to = top.getTo();

      stack.pop();
      
      if(to.hasRight())
        stack.push(ConstEdge(to, *to.getRight()));

      if(to.hasLeft())
        stack.push(ConstEdge(to, *to.getLeft()));
    }

  private:
    std::stack<ConstEdge> stack;

    friend class BinaryTree;
  };

public:
  // Creates an empty tree. The "BinaryTree<Ty>" is just an handler used to hide
  // tree internal representation.
  static BinaryTree<Ty> createEmpty() {
    return BinaryTree();
  }

  // A random tree is created by simply inserting a random sequence of elements
  // into the tree.
  static BinaryTree<Ty> createRandom(unsigned nodes = 16) {
    typename RandomTraits<Ty>::random_iterator
      i = RandomTraits<Ty>::random_begin(nodes),
      e = RandomTraits<Ty>::random_end();

    BinaryTree<Ty> tree = BinaryTree<Ty>::createEmpty();

    for(; i != e; ++i)
      tree.insert(*i);

    return tree;
  }

  static BinaryTree<Ty> createOddRandom(unsigned nodes = 16) {
    typename RandomTraits<Ty>::random_iterator
      i = RandomTraits<Ty>::random_begin(nodes),
      e = RandomTraits<Ty>::random_end();

    BinaryTree<Ty> tree = BinaryTree<Ty>::createEmpty();

    for(; i != e; ++i) {
      if(IndexTraits<Ty>::index(*i) & 1)
        continue;

      tree.insert(*i);
    }

    return tree;
  }

  static BinaryTree<Ty> createEvenRandom(unsigned nodes = 16) {
    typename RandomTraits<Ty>::random_iterator
      i = RandomTraits<Ty>::random_begin(nodes),
      e = RandomTraits<Ty>::random_end();

    BinaryTree<Ty> tree = BinaryTree<Ty>::createEmpty();

    for(; i != e; ++i)
      if(IndexTraits<Ty>::index(*i) & 1)
        tree.insert(*i);

    return tree;
  }

public:
  const_pre_order_node_iterator pre_order_node_begin() const {
    return const_pre_order_node_iterator(root.get());
  }

  const_pre_order_node_iterator pre_order_node_end() const {
    return const_pre_order_node_iterator();
  }

  const_in_order_node_iterator in_order_node_begin() const {
    return const_in_order_node_iterator(root.get());
  }

  const_in_order_node_iterator in_order_node_end() const {
    return const_in_order_node_iterator();
  }

  const_post_order_node_iterator post_order_node_begin() const {
    return const_post_order_node_iterator(root.get());
  }

  const_post_order_node_iterator post_order_node_end() const {
    return const_post_order_node_iterator();
  }

  const_edge_iterator edge_begin() const {
    return const_edge_iterator(root.get());
  }

  const_edge_iterator edge_end() const {
    return const_edge_iterator();
  }

private:
  BinaryTree() : root(NULL) { }

public:
  BinaryTree(const BinaryTree &that) :
    root(!that.empty() ? new Node(*that.getRoot()) : NULL) {
  }

  const BinaryTree &operator=(const BinaryTree &that) {
    if(this == &that)
      return;

    if(!that.empty())
      setRoot(new Node(*that.getRoot()));
  }

public:
  // The insert method hide the complexity of creating the tree. In particular,
  // we hide the fact that the root is represented using a "NULL" pointer.
  void insert(const Ty &elt) {
    if(empty())
      setRoot(new Node(elt));
    else
      root->insert(elt);
  }

  Node *getRoot() const {
    return root.get();
  }

public:
  size_t size() const {
    size_t size = 0;

    for(const_pre_order_node_iterator i = pre_order_node_begin(),
                                      e = pre_order_node_end();
                                      i != e;
                                      ++i)
      ++size;

    return size;
  }

  bool empty() const {
    return !root.get();
  }

public:
  void dump() const;

private:
  void setRoot(Node *node) {
    root.reset(node);
  }

private:
  std::auto_ptr<Node> root;
};

//
// DOTPrinterBase implementation.
//

// Having a tree without being able to print it is useless. This class
// implements a pretty printer for a binary tree.
//
// Since the "BinaryTree" class is a template, the pretty printer should be a
// template. However there are some static fields not depending on template
// parameters, so a common technique is to put all template-independent code in
// a separate super-class. That class is not intended to be used, it is just a
// programming trick.
class DOTPrinterBase {
public:
  // Enum are a bad thing because they can be casted to integer. Class enum is a
  // C++ idiom used to create compile-time verified enums.
  class VisitMode {
  private:
    // These are all possible values of our enum. By making the enumeration
    // private, we avoid users accessing to invalid enum codes.
    enum Mode {
      PreOrder,
      InOrder,
      PostOrder
    };

  public:
    // This is the list of all available enum values. Users of this class can
    // use only that enums. Invalid enums cannot be produces because "VisitMode"
    // constructor is private.
    static const VisitMode preOrder;
    static const VisitMode inOrder;
    static const VisitMode postOrder;

  private:
    VisitMode(Mode mode) : mode(mode) { }

  public:
    bool operator==(const VisitMode &that) const {
      return this == &that;
    }
    
    bool operator!=(const VisitMode &that) const {
      return !(*this == that);
    }

  private:
    // The enum state is just the code of the enum.
    Mode mode;
  };

protected:
  DOTPrinterBase(std::ostream &os = std::cerr) :
    os(os),
    visitMode(&VisitMode::inOrder) {
    os << "digraph trees {" << std::endl;
  }

  ~DOTPrinterBase() {
    os << "}" << std::endl;
  }

protected:
  void setMode(const VisitMode &mode) {
    visitMode = &mode;
  }

  std::string nodeName(unsigned treeIdx, unsigned nodeIdx) const {
    std::stringstream name;

    name << "\"" << treeIdx << "-" << nodeIdx << "\"";

    return name.str();
  }

protected:
  std::ostream &os;
  const VisitMode *visitMode;
};

const DOTPrinterBase::VisitMode
  DOTPrinterBase::VisitMode::preOrder(DOTPrinterBase::VisitMode::PreOrder);

const DOTPrinterBase::VisitMode
  DOTPrinterBase::VisitMode::inOrder(DOTPrinterBase::VisitMode::InOrder);

const DOTPrinterBase::VisitMode
  DOTPrinterBase::VisitMode::postOrder(DOTPrinterBase::VisitMode::PostOrder);

// Here we produce the final pretty printer by sub-classing "DOTPrinterBase" and
// adding the template paremeter identifying the type of the tree.
template <typename Ty>
class DOTPrinter : public DOTPrinterBase {
public:
  DOTPrinter(std::ostream &os = std::cerr) : DOTPrinterBase(os) { }

public:
  // The pretty printer is configurable with a manipulator. Inserting a
  // manipulator into the pretty printer results on changing the way subsequent
  // trees are printed.
  DOTPrinter &operator<<(const VisitMode &mode) {
    setMode(mode);

    return *this;
  }

  // Inserting a tree into the pretty printer emits a dot description of the
  // tree. Nodes in the tree are visited according to the current "VisitMode".
  // This results on coloring nodes with different colors, depending on the
  // access order.
  DOTPrinter &operator<<(const BinaryTree<Ty> &tree) {
    os << "{" << std::endl;

    #define PRINT_NODES(M, I)                                             \
      if(*visitMode == VisitMode::M)                                      \
        printNodes(tree, tree.I ## _node_begin(), tree.I ## _node_end());

    PRINT_NODES(preOrder, pre_order)
    PRINT_NODES(inOrder, in_order)
    PRINT_NODES(postOrder, post_order)

    #undef PRINT_NODES

    printEdges(tree);

    os << "}" << std::endl;

    return *this;
  }

private:
  template <typename IterTy>
  void printNodes(const BinaryTree<Ty> &tree, IterTy i, IterTy e) {
    unsigned treeIdx = reinterpret_cast<unsigned>(&tree);
    float alpha = 0.0, alphaStep = 255.0 / tree.size();

    for(; i != e; ++i) {
      std::ostream::fmtflags flags;

      unsigned idx = i->getIndex();
  
      os << "node [label = \"" << idx << "\", "
         << "style = \"filled\", ";
      
      flags = os.flags();
      os << "fillcolor = \"#ff0000" << std::hex << unsigned(alpha) << "\"] ";
      os.flags(flags);

      os << nodeName(treeIdx, idx)
         << std::endl;

      alpha += alphaStep;
    }
  }

  void printEdges(const BinaryTree<Ty> &tree) {
    typedef typename BinaryTree<Ty>::Node Node;
    typedef typename BinaryTree<Ty>::const_edge_iterator edge_iterator;

    unsigned treeIdx = reinterpret_cast<unsigned>(&tree);

    for(edge_iterator i = tree.edge_begin(), e = tree.edge_end(); i != e; ++i) {
      const Node &from = i->getFrom(),
                 &to = i->getTo();

      os << nodeName(treeIdx, from.getIndex())
         << " -> "
         << nodeName(treeIdx, to.getIndex())
         << std::endl;
    }
  }
};

//
// BinaryTree<Ty> remaining implementation.
//

// To dump a tree we can use the freshly defined pretty printer. However, to use
// the printer its definition must be complete -- i.e. no forward declaration --
// so we cannot implement "BinaryTree<Ty>::dump" at declaration time -- we have
// to implement the pretty printer first.
template <typename Ty> inline
void BinaryTree<Ty>::dump() const {
  DOTPrinter<Ty> printer;

  printer << *this;
}

// Here we define the sum of two trees as the tree containing nodes of the two
// trees. The operation creates a new fresh tree -- operands not modified.
template <typename Ty> inline
BinaryTree<Ty> operator+(const BinaryTree<Ty> &treeA,
                         const BinaryTree<Ty> &treeB) {
  typedef typename BinaryTree<Ty>::const_in_order_node_iterator node_iterator;

  BinaryTree<Ty> tree = treeA;

  for(node_iterator i = treeB.in_order_node_begin(),
                    e = treeB.in_order_node_end();
                    i != e;
                    ++i)
    tree.insert(i->getElt());

  return tree;
}

// Since we want expression involving trees to be lazily evaluated, specialize
// the "LazyTraits<Ty>" trait.
template <typename Ty>
struct LazyTraits<BinaryTree<Ty> > {
  static BinaryTree<Ty> add(const BinaryTree<Ty> &treeA,
                            const BinaryTree<Ty> &treeB) {
    return treeA + treeB;
  }
};

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  BinaryTree<unsigned> treeA = BinaryTree<unsigned>::createRandom();
  BinaryTree<unsigned> treeB = BinaryTree<unsigned>::createOddRandom();
  BinaryTree<unsigned> treeC = BinaryTree<unsigned>::createEvenRandom();

  DOTPrinter<unsigned> printer;

  printer << DOTPrinterBase::VisitMode::preOrder  << treeA
          << DOTPrinterBase::VisitMode::inOrder   << treeB
          << DOTPrinterBase::VisitMode::postOrder << treeC;

  BinaryTree<unsigned> treeD = lazy(treeB) + lazy(treeC);

  printer << DOTPrinterBase::VisitMode::preOrder << treeD;

  return EXIT_SUCCESS;
}
