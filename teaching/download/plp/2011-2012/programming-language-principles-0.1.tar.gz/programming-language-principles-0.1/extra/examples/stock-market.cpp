
#include <iostream>
#include <queue>

#include <cstdlib>

namespace plp {

class Analysis {
public:
  virtual ~Analysis() { }

public:
  virtual void operator()() = 0;
};

#define ANALYSIS(C) \
  class C : public Analysis {                              \
  public:                                                  \
    virtual void operator()() {                            \
      std::cerr << "Running Analysis " << #C << std::endl; \
    }                                                      \
  };

ANALYSIS(FooAnalysis)
ANALYSIS(BarAnalysis)
ANALYSIS(BazAnalysis)
ANALYSIS(BizAnalysis)
ANALYSIS(CipAnalysis)
ANALYSIS(CiopAnalysis)

#undef ANALYSIS

class Flush {
public:
  ~Flush() {
    std::cerr << "Queue Flushed" << std::endl;
  }
};

class StockServer {
public:
  StockServer() : cost(0) { }

  ~StockServer() {
    flushQueue();

    std::cerr << "Server Fee = " << (1000 * cost) << "$" << std::endl;
  }

public:
  StockServer &operator<<(Analysis *cmd) {
    queue.push(cmd);

    return *this;
  }
  
  StockServer &operator<<(Flush *cmd) {
    flushQueue();

    delete cmd;

    return *this;
  }

private:
  void flushQueue() {
    while(!queue.empty()) {
      Analysis *cmd;
      
      cmd = queue.front();
      queue.pop();

      (*cmd)();

      delete cmd;
    }

    ++cost;
  }

private:
  std::queue<Analysis *> queue;
  unsigned long cost;
};

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  StockServer srv;

  srv << new FooAnalysis()
      << new BarAnalysis()
      << new BazAnalysis()
      << new BizAnalysis()
      << new Flush()
      << new CipAnalysis()
      << new CiopAnalysis();

  return EXIT_SUCCESS;
}
