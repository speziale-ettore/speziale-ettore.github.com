
#include <iostream>

#include <cstdlib>

namespace plp {

template <typename Ty, unsigned Size = 64>
class CircularBuffer {
public:
  CircularBuffer() : head(-1),
                     tail(0) { }

public:
  const Ty &front() const {
    return storage[head];
  }

  const Ty &back() const {
    return (tail == 0) ? storage[Size - 1] : storage[tail - 1];
  }

  void push(const Ty &elt) {
    // Full buffer.
    if(tail == head)
      return;

    // Empty buffer.
    if(head == -1)
      head = tail;

    storage[tail] = elt;
    tail = (tail + 1) % Size;
  }

  void pop() {
    // Empty buffer.
    if(head == -1)
      return;

    head = (head + 1) % Size;

    // Buffer becomes empty.
    if(head == tail)
      head = -1;
  }

  size_t capacity() const {
    return Size;
  }

  size_t size() const {
    // Empty buffer.
    if(head == -1)
      return 0;

    return (tail > head) ? (tail - head) : (Size - head + tail);
  }

  bool empty() const {
    return size() == 0;
  }

private:
  Ty storage[Size];

  int head;
  int tail;
};

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  CircularBuffer<char> buffer;

  const char *i = "Hello, World!";

  while(*i)
    buffer.push(*i++);
  
  while(!buffer.empty()) {
    std::cerr << buffer.front();
    buffer.pop();
  }
  std::cerr << std::endl;

  return EXIT_SUCCESS;
}
