
#include <iostream>
#include <vector>

#include <cstdlib>

namespace plp {

struct DefaultRenderTraits {
  class member {
  public:
    enum visibility {
      vis_public,
      vis_protected,
      vis_private
    };

  public:
    member(visibility vis, const char *name) : vis(vis),
                                               name(name) { }

  public:
    visibility get_visibility() const {
      return vis;
    }

    const std::string &get_name() const {
      return name;
    }

  private:
    visibility vis;
    std::string name;
  };

  typedef std::vector<member>::const_iterator member_iterator;

  typedef member_iterator cons_iterator;
  typedef member_iterator func_iterator;
  typedef member_iterator attr_iterator;

  static std::string getName();

  // Specialize in subclasses to iterate over constructors.
  //
  // static cons_iterator cons_begin(); 
  // static cons_iterator cons_end();
  
  // Specialize in subclasses to iterate over member functions.
  //
  // static func_iterator func_begin(); 
  // static func_iterator func_end();

  // Specialize in subclasses to iterate over attributes.
  //
  // static attr_iterator attr_begin(); 
  // static attr_iterator attr_end();
};

std::ostream &operator<<(std::ostream &os,
                         const DefaultRenderTraits::member::visibility &vis) {
  #define VISIBILITY(V, N)               \
    case DefaultRenderTraits::member::V: \
      return os << N;

  switch(vis) {
    VISIBILITY(vis_public, "+")
    VISIBILITY(vis_protected, "#")
    VISIBILITY(vis_private, "-")
  }

  #undef VISIBILITY
}

std::ostream &operator<<(std::ostream &os,
                         const DefaultRenderTraits::member &member) {
  return os << member.get_visibility() << " " << member.get_name();
}

template <typename Ty>
struct RenderTraits;

class Renderer {
public:
  Renderer(std::ostream &os = std::cerr) : os(os) {
    std::cerr << "Welcome to 'Los Tres Amigos'" << std::endl;
  }

  ~Renderer() {
    std::cerr << "Bye, Bye" << std::endl;
  }

public:
  template <typename Ty>
  void render(const Ty &ty) {
    std::cerr << RenderTraits<Ty>::getName() << ":" <<std::endl;

    typedef typename RenderTraits<Ty>::cons_iterator cons_iterator;
    typedef typename RenderTraits<Ty>::func_iterator func_iterator;
    typedef typename RenderTraits<Ty>::attr_iterator attr_iterator;

    for(cons_iterator i = RenderTraits<Ty>::cons_begin(),
                      e = RenderTraits<Ty>::cons_end();
                      i != e;
                      ++i)
      std::cerr << "  " << *i << std::endl;

    for(func_iterator i = RenderTraits<Ty>::func_begin(),
                      e = RenderTraits<Ty>::func_end();
                      i != e;
                      ++i)
      std::cerr << "  " << *i << std::endl;

    for(attr_iterator i = RenderTraits<Ty>::attr_begin(),
                      e = RenderTraits<Ty>::attr_end();
                      i != e;
                      ++i)
      std::cerr << "  " << *i << std::endl;
  }

private:
  std::ostream &os;
};

class Foo {
public:
  Foo() { }

protected:
  void method() { }

private:
  int field;
};

struct Bar {
  int upper;
  int lower;
};

enum Baz {
  Cip,
  Ciop
};

// The following macro specialize 'RenderTraits' in order to provide a
// "reflection-like" behaviour. The only thing the macro does not do is filling
// the containers for constructors, member functions and attributes with the
// correct values.
//
// Filling these information should be done in the static constructor. C++ lacks
// native support for static constructor, so we use the GCC attribute
// 'constructor to tell the compiler that the marked function should be called
// every time the object file is loaded in memory -- that is the static
// constructor of the class.
#define RENDER(T)                                                         \
  template <>                                                             \
  class RenderTraits<T> : public DefaultRenderTraits {                    \
  public:                                                                 \
    static std::string getName() {                                        \
      return #T;                                                          \
    }                                                                     \
                                                                          \
    static cons_iterator cons_begin() {                                   \
      return constructors.begin();                                        \
    }                                                                     \
                                                                          \
    static cons_iterator cons_end() {                                     \
      return constructors.end();                                          \
    }                                                                     \
                                                                          \
    static func_iterator func_begin() {                                   \
      return functions.begin();                                           \
    }                                                                     \
                                                                          \
    static func_iterator func_end() {                                     \
      return functions.end();                                             \
    }                                                                     \
                                                                          \
    static attr_iterator attr_begin() {                                   \
      return attributes.begin();                                          \
    }                                                                     \
                                                                          \
    static attr_iterator attr_end() {                                     \
      return attributes.end();                                            \
    }                                                                     \
                                                                          \
  private:                                                                \
    __attribute__((constructor))                                          \
    static void static_init();                                            \
                                                                          \
  private:                                                                \
    static std::vector<member> constructors;                              \
    static std::vector<member> functions;                                 \
    static std::vector<member> attributes;                                \
  };                                                                      \
                                                                          \
  std::vector<DefaultRenderTraits::member> RenderTraits<T>::constructors; \
  std::vector<DefaultRenderTraits::member> RenderTraits<T>::functions;    \
  std::vector<DefaultRenderTraits::member> RenderTraits<T>::attributes;

RENDER(Foo)
RENDER(Bar)
RENDER(Baz)

#undef RENDER

__attribute__((constructor))
void RenderTraits<Foo>::static_init() {
  constructors.push_back(member(member::vis_public, "Foo()"));

  functions.push_back(member(member::vis_protected, "void method()"));

  attributes.push_back(member(member::vis_private, "int field"));
}

__attribute__((constructor))
void RenderTraits<Bar>::static_init() {
  attributes.push_back(member(member::vis_public, "int upper"));
  attributes.push_back(member(member::vis_public, "int lower"));
}

__attribute__((constructor))
void RenderTraits<Baz>::static_init() {
  attributes.push_back(member(member::vis_public, "Cip"));
  attributes.push_back(member(member::vis_public, "Ciop"));
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  Renderer tool;

  tool.render(Foo());
  tool.render(Bar());
  tool.render(Cip);

  return EXIT_SUCCESS;
}
