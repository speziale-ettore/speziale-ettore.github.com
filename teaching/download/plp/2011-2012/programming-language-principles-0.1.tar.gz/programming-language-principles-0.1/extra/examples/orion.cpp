
#include <iostream>

#include <cstdlib>

namespace plp {

class SafeFloat {
public:
  SafeFloat(float flt = 0.0) {
    flts[0] = flts[1] = flts[2] = flt;
  };

  SafeFloat(float flts[3]) {
    this->flts[0] = flts[0];
    this->flts[1] = flts[1];
    this->flts[2] = flts[2];

    check();
  }

public:
  const SafeFloat &operator+=(SafeFloat flt) {
    flts[0] += flt.flts[0];
    flts[1] += flt.flts[1];
    flts[2] += flt.flts[2];

    check();

    return *this;
  }

  float read() {
    check();
    
    return flts[0];
  }

private:
  void check() {
    if(flts[0] == flts[1] && flts[1] == flts[2])
      return;

    if(flts[0] == flts[1])
      flts[2] = flts[0];

    else if(flts[0] == flts[2])
      flts[1] = flts[0];

    else if(flts[1] == flts[2])
      flts[0] = flts[1];

    abort();
  }

private:
  float flts[3];

  #define OPERATOR(OP)                                   \
    friend SafeFloat operator OP (SafeFloat, SafeFloat);

  OPERATOR(+)
  OPERATOR(-)
  OPERATOR(*)
  OPERATOR(/)

  #undef OPERATOR
};

#define OPERATOR(OP)                                 \
  SafeFloat operator OP (SafeFloat a, SafeFloat b) { \
    float flts[3] = { a.flts[0] OP b.flts[0],        \
                      a.flts[1] OP b.flts[1],        \
                      a.flts[2] OP b.flts[2] };      \
                                                     \
    return SafeFloat(flts);                          \
  }

OPERATOR(+)
OPERATOR(-)
OPERATOR(*)
OPERATOR(/)

#undef OPERATOR

std::ostream &operator<<(std::ostream &os, SafeFloat flt) {
  return os << flt.read();
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  SafeFloat a = 10.0, v = 0.0, x = 0.0;

  for(unsigned i = 1; i < 10; ++i) {
    v += a;
    x += a * (2 * i - 1);

    std::cerr << "[Time = " << i << "s]" << std::endl
              << " Altitude = " << x << "m" << std::endl
              << " Speed = " << v << "m/s" << std::endl;
  }

  return EXIT_SUCCESS;
}
