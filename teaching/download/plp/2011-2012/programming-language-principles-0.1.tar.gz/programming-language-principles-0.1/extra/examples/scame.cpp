
#include <iostream>
#include <vector>

#include <cstdlib>

namespace plp {

class ScameStr {
private:
  class Char {
  private:
    enum Case {
      Lower,
      Upper,
      None
    };

  public:
    static const Char &get(char chr) {
      if(std::islower(chr))
        return chars[chr - 'a'];

      else if(std::isupper(chr))
        return chars[('z' - 'a') + (chr - 'A') + 1];

      else if(std::isdigit(chr))
        return chars[('z' - 'a') + ('Z' - 'A') + (chr - '0') + 1];

      else if(chr == ' ')
        return chars[('z' - 'a') + ('Z' - 'A') + ('9' - '0') + 1 + 1];

      abort();
    }

  private:
    __attribute__((constructor))
    static void staticInit();

  private:
    static std::vector<Char> chars;

  private:
    Char(char chr, Case chrCase) : chrCase(chrCase) {
      if(std::isalpha(chr))
        this->chr = std::tolower(chr);

      else if(std::isdigit(chr) || chr == ' ')
        this->chr = chr;

      else
        abort();
    }

  public:
    operator char() const {
      return (chrCase == Upper) ? ('A' + chr - 'a') : (chr);
    }

  public:
    char chr;
    Case chrCase;
  };

public:
  ScameStr(const char *str = NULL) {
    if(!str)
      return;

    while(*str)
      storage.push_back(&Char::get(*str++));
  }

public:
  operator std::string() const {
    std::string str;

    for(std::vector<const Char *>::const_iterator i = storage.begin(),
                                                  e = storage.end();
                                                  i != e;
                                                  ++i)
      str.push_back(**i);

    return str;
  }

private:
  std::vector<const Char *> storage;
};

__attribute__((constructor))
void ScameStr::Char::staticInit() {
  for(char i = 'a', e = 'z' + 1; i != e; ++i)
    chars.push_back(Char(i, Lower));

  for(char i = 'A', e = 'Z' + 1; i != e; ++i)
    chars.push_back(Char(i, Upper));

  for(char i = '0', e = '9'; i != e; ++i)
    chars.push_back(Char(i, None));

  chars.push_back(Char(' ', None));
}

std::vector<ScameStr::Char> ScameStr::Char::chars;

std::ostream &operator<<(std::ostream &os, const ScameStr &str) {
  return os << static_cast<const std::string &>(str);
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  ScameStr msg = "We Will Expect to Reduce Memory Consumption";

  std::cerr << msg << std::endl;

  return EXIT_SUCCESS;
}
