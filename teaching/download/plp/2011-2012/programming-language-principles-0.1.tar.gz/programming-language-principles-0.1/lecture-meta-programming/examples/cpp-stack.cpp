
#include <iostream>

#include <cstdlib>

#define STACK_MAX_SIZE 16

namespace plp {

// A simple stack of fixed size. We used "void *" to abstract from the type of
// contained pointers, in order to factorize code.
class Stack {
public:
  typedef void **iterator;

  iterator begin() { return storage; }
  iterator end() { return storage + top; }

public:
  Stack() : top(0) { }

  void *push(void *elem) {
    if(top >= STACK_MAX_SIZE)
      return NULL;

    storage[top++] = elem;

    return elem;
  }

  void *pop() {
    return top != 0 ? storage[--top] : NULL;
  }

  size_t size() { return top; }
  size_t capacity() { return STACK_MAX_SIZE; }

public:
  void dump();

private:
  void *storage[STACK_MAX_SIZE];
  unsigned top;
};

std::ostream &operator<<(std::ostream &os, Stack &stack) {
  os << "Stack with "
     << stack.size() << "/" << stack.capacity()
     << " elements: [";

  for(Stack::iterator i = stack.begin(), e = stack.end(); i != e; ++i)
    os << " " << *i;

  os << " ]" << std::endl;

  return os;
}

} // End namespace plp.

using namespace plp;

void Stack::dump() {
  std::cerr << *this;
}

int main(int argc, char *argv[]) {
  Stack stack;

  stack.dump();

  // In order to support different types, we selected a "void *"-based
  // representation. This allows to factorize code for stack handling, but it
  // makes harder:

  // 1) inserting stored elements -> stack store addresses rather than values.
  std::cerr << "Push: "
            << *reinterpret_cast<int *>(stack.push(new int(7)))
            << std::endl;

  std::cerr << "Push: "
            << *reinterpret_cast<int *>(stack.push(new int(11)))
            << std::endl;

  stack.dump();

  // 2) accessing elements -> stack is not aware of the type of elements it
  // contains, so client code must perform a cast.
  std::cerr << "Pop: " << *reinterpret_cast<int *>(stack.pop()) << std::endl;

  stack.dump();

  return EXIT_SUCCESS;
}
