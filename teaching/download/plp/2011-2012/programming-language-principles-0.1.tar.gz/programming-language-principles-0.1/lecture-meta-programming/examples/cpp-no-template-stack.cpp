
#include <iostream>

#include <cstdlib>

#define STACK_MAX_SIZE 16

namespace plp {

// In order to make using of the stack easier, we want to augment "Stack" in
// order to avoid using "void *" in the client code. We cannot use
// sub-classing because some methods cannot be "masked":
//
// e.g.: suppose we mask "void *Stack::pop()" with "int *Stack::pop()". This is
//       not possible, due to C++ overloading rules
//
// The alternative is to exploit macros. We get a more friendly interface, and a
// more efficient in-line layout.
//
// Please notice that when an invalid operation is executed -- e.g. calling
// "Stack_ ## T::push" on a full stack -- we cannot return NULL to signal the
// error. Since we don't know an 'error value' for the type T, we have to abort.

#define DEFINE_STACK(T)                                                        \
  class Stack_ ## T {                                                          \
  public:                                                                      \
    typedef T *iterator;                                                       \
                                                                               \
    iterator begin() { return storage; }                                       \
    iterator end() { return storage + top; }                                   \
                                                                               \
  public:                                                                      \
    Stack_ ## T() : top(0) { }                                                 \
                                                                               \
    T &push(const T &elem) {                                                   \
      if(top >= STACK_MAX_SIZE)                                                \
        abort();                                                               \
                                                                               \
      storage[top++] = elem;                                                   \
                                                                               \
      return storage[top - 1];                                                 \
    }                                                                          \
                                                                               \
    T pop() {                                                                  \
      if(top == 0)                                                             \
        abort();                                                               \
                                                                               \
      return storage[--top];                                                   \
    }                                                                          \
                                                                               \
    size_t size() { return top; }                                              \
    size_t capacity() { return STACK_MAX_SIZE; }                               \
                                                                               \
  public:                                                                      \
    void dump();                                                               \
                                                                               \
  private:                                                                     \
    T storage[STACK_MAX_SIZE];                                                 \
    unsigned top;                                                              \
  };                                                                           \
                                                                               \
  std::ostream &operator<<(std::ostream &os, Stack_ ## T &stack) {             \
    os << "Stack with "                                                        \
       << stack.size() << "/" << stack.capacity()                              \
       << " elements: [";                                                      \
                                                                               \
    for(Stack_ ## T::iterator i = stack.begin(), e = stack.end(); i != e; ++i) \
      os << " " << *i;                                                         \
                                                                               \
    os << " ]" << std::endl;                                                   \
                                                                               \
    return os;                                                                 \
  }                                                                            \
                                                                               \
  void Stack_ ## T::dump() {                                                   \
    std::cerr << *this;                                                        \
  }

DEFINE_STACK(int)

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  Stack_int stack;

  stack.dump();

  std::cerr << "Push: " << stack.push(7) << std::endl;
  std::cerr << "Push: " << stack.push(11) << std::endl;

  stack.dump();

  std::cerr << "Pop: " << stack.pop() << std::endl;

  stack.dump();

  return EXIT_SUCCESS;
}
