
#include <iostream>

#include <cstdlib>

namespace plp {

// Templates allows to define a parametric class. Here the "Stack" class
// template is declared. Parameters are the type of stack elements, "Ty", and
// the stack maximum size, "StackMaxSize". The second has a default value -- 16. 
//
// Please notice that when an invalid operation is executed -- e.g. calling
// "Stack<Ty, StackMaxSize>::push" on a full stack -- we cannot return NULL to
// signal the error. Since we don't know an 'error value' for the type Ty, we
// have to abort.
template <typename Ty, unsigned StackMaxSize = 16>
class Stack {
public:
  typedef Ty *iterator;

  iterator begin() { return storage; }
  iterator end() { return storage + top; }

public:
  Stack() : top(0) { }

  Ty &push(const Ty &elem) {
    if(top >= StackMaxSize)
      abort();

    storage[top++] = elem;

    return storage[top - 1];
  }

  Ty pop() {
    if(top == 0)
      abort();

    return storage[--top];
  }

  size_t size() { return top; }
  size_t capacity() { return StackMaxSize; }

public:
  // Defining a template member function out-of-line is often useless. A
  // template is generic code, will be always inlined.
  void dump() {
    std::cerr << *this;
  }

private:
  // Here the two template arguments are used for two different goals. The "Ty"
  // parameter, a type, is used to declare "storage" array element type, while
  // the "StackMaxSize" value parameter is used to declare array size.
  Ty storage[StackMaxSize];
  unsigned top;
};

template <typename Ty, unsigned MaxStackSize>
std::ostream &operator<<(std::ostream &os, Stack<Ty, MaxStackSize> &stack) {
  // The type definition here is only for convenience. Please notice the usage
  // of the "typename" keyword to tell C++ parser the following token refers to
  // a type.
  typedef typename Stack<Ty, MaxStackSize>::iterator iterator;

  os << "Stack with "
     << stack.size() << "/" << stack.capacity()
     << " elements: [";

  for(iterator i = stack.begin(), e = stack.end(); i != e; ++i)
    os << " " << *i;

  os << " ]" << std::endl;

  return os;
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  // This instantiate the "Stack" template for the "<int,16>" pair.
  Stack<int> stack;

  stack.dump();

  std::cerr << "Push: " << stack.push(7) << std::endl;
  std::cerr << "Push: " << stack.push(11) << std::endl;

  stack.dump();

  std::cerr << "Pop: " << stack.pop() << std::endl;

  stack.dump();

  return EXIT_SUCCESS;
}
