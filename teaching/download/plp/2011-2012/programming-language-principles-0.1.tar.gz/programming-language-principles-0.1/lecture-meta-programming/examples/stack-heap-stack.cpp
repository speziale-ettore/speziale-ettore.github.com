
#include <iostream>

#include <cstdlib>
#include <cstring>

namespace plp {

// This class is intended to hold data and algorithms independent from
// templates. Usually it will contains implementations of expensive member
// functions.
class StackBase {
protected:
  StackBase(unsigned size) :
    storage(new uint8_t[size]),
    storageBegin(storage),
    expanded(false) { }

  ~StackBase() {
    delete storage;
  }

protected:
  // The stack can be expanded. In order to do this we have to invoke this
  // 'expensive' member function.
  void expand(unsigned oldSize) {
    if(expanded)
      abort();

    // Stack expansion is trivial: copy the contents of old storage are into the
    // heap-allocated storage, and update stack base address.
    std::memcpy(storage, storageBegin, oldSize);
    storageBegin = storage;

    expanded = true;
  }

protected:
  // This represents the memory chunk holding the complete stack.
  uint8_t *storage;

  // This points to the start of the stack.
  uint8_t *storageBegin;

  // For sake of simplicity, we allow expanding the stack only once.
  bool expanded;
};

// Here we derive "StackBase" and we use templates to provide a more friendly
// interface. Moreover, we add interior storage for a part of the stack -- we
// expect better performances when the stack is stored interiorly.
template <typename Ty, unsigned StackMaxSize = 4>
class Stack : public StackBase {
public:
  // Iterators are defined using the pointer to stack base -- this allows
  // transparently using internal or external storage.

  typedef Ty *iterator;

  iterator begin() { return reinterpret_cast<Ty *>(storageBegin); }
  iterator end() { return reinterpret_cast<Ty *>(storageBegin) + top; }

public:
  Stack() : StackBase(StackMaxSize * sizeof(Ty)),
                      top(0) {
    storageBegin = reinterpret_cast<uint8_t *>(storage);
  }

public:
  Ty &push(const Ty &elem) {
    // If we reach internal storage limit, expand the stack on the heap.
    if(top == StackMaxSize / 2)
      expand( StackMaxSize / 2 * sizeof(Ty));

    // Allows expanding the stack only one time.
    else if(top == StackMaxSize)
      abort();

    // Stack operation are performed using the stack base pointer, thus
    // abstracting from the stack storage.
    Ty *storage = reinterpret_cast<Ty *>(storageBegin);
    storage[top++] = elem;

    return storage[top - 1];
  }

  Ty pop() {
    if(top == 0)
      abort();

    Ty *storage = reinterpret_cast<Ty *>(storageBegin);

    return storage[--top];
  }

public:
  size_t size() { return top; }
  size_t capacity() { return StackMaxSize; }

public:
  void dump() {
    std::cerr << *this;
  }

private:
  Ty storage[StackMaxSize / 2];
  unsigned top;
};

template <typename Ty, unsigned MaxStackSize>
std::ostream &operator<<(std::ostream &os, Stack<Ty, MaxStackSize> &stack) {
  typedef typename Stack<Ty, MaxStackSize>::iterator iterator;

  os << "Stack with "
     << stack.size() << "/" << stack.capacity()
     << " elements: [";

  for(iterator i = stack.begin(), e = stack.end(); i != e; ++i)
    os << " " << *i;

  os << " ]" << std::endl;

  return os;
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  Stack<int> stack;

  stack.dump();

  std::cerr << "Push: " << stack.push(7) << std::endl;
  std::cerr << "Push: " << stack.push(11) << std::endl;
  std::cerr << "Push: " << stack.push(13) << std::endl;

  stack.dump();

  std::cerr << "Pop: " << stack.pop() << std::endl;

  stack.dump();

  return EXIT_SUCCESS;
}
