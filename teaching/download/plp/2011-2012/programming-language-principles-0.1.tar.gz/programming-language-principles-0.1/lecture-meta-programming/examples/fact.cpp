
#include <iostream>

#include <cstdlib>

namespace plp {

// The template general declaration is used to start recursion.
template <unsigned N>
struct fact {
  enum { value = N * fact<N - 1>::value };
};

// Specializing the template for 0, we block recursion, so compile-time
// computations ends here.
template <>
struct fact<0> {
  enum { value = 1 };
};

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  std::cout << "Factorial of 4: " << fact<4>::value << std::endl;

  return EXIT_SUCCESS;
}
