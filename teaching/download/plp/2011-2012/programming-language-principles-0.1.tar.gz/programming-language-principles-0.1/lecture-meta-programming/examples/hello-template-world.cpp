
#include <iostream>

#include <cstdlib>

namespace plp {

enum Lang {
  It,
  En
};

// An enum is an integer, thus is can be used as template value parameter. Here
// we are declaring the template, without giving an implementation. This is
// legal, we are just telling the compiler that the "helloWorld" function is
// parametrized.
template <enum Lang Lang>
void helloWorld();

// Here we specialize the "helloWorld" function for the Italian language.
template <>
void helloWorld<It>() {
  std::cout << "Ciao, Mondo!" << std::endl;
}

// Same as above, but for English.
template <>
void helloWorld<En>() {
  std::cout << "Hello, World!" << std::endl;
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {

  // A couple of references to the "helloWorld" template. Both trigger code
  // generation. Both references are matched by a different specialization,
  // Italian and English respectively.
  helloWorld<It>();
  helloWorld<En>();

  return EXIT_SUCCESS;
}
