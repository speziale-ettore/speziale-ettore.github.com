
#include <iostream>
#include <list>
#include <vector>

#include <cstdlib>

namespace plp {

// The "StackTraits" trait allows to declare a set of operations that must be
// implemented by something acting like a stack. Here we put only declarations.
// This ensures that if the trait is used with a type not specializing it, a
// link-time error occurs.
template <typename Ty>
struct StackTraits {
  static const char *name(Ty &stack);

  static void reset(Ty &stack);

  static void push(Ty &stack, int elem);
  static int pop(Ty &stack);

  static bool empty(Ty &stack);
};

// This algorithms fill a stack. It used traits to abstract from the actual type
// providing storage for the stack. It is something like exploiting virtual
// table and sub-type polymorphism. The difference is that with traits code is
// in-lined -- we get better performance and we avoid using a virtual table.
template <typename Ty>
void buildSampleStack(Ty &stack) {
  StackTraits<Ty>::reset(stack);

  StackTraits<Ty>::push(stack, 0);
  StackTraits<Ty>::push(stack, 1);
}

template <typename Ty>
void visitStack(Ty &stack) {
  std::cout << "Stack (" << StackTraits<Ty>::name(stack) << ") contents: [";
  while(!StackTraits<Ty>::empty(stack))
    std::cout << " " << StackTraits<Ty>::pop(stack);
  std::cout << " ]" << std::endl;
}

// By specializing the "StackTraits" trait for "std::vector<int>" we can use an
// STL vector as storage for the stack.
template <>
struct StackTraits<std::vector<int> > {
  static const char *name(std::vector<int> &stack) {
    return "std::vector";
  }

  static void reset(std::vector<int> &stack) {
    stack.clear();
  }

  static void push(std::vector<int> &stack, int elem) {
    stack.push_back(elem);
  }

  static int pop(std::vector<int> &stack) {
    int elem = stack.back();

    stack.pop_back();

    return elem;
  }

  static bool empty(std::vector<int> &stack) {
    return stack.empty();
  }
};

// Same as above, but for an STL list. Please notice that specialization
// implements a different algorithm. Here stack top is the head, of the list,
// while for "std::vector<int>" specialization stack top is the tail of the
// sequence.
template <>
struct StackTraits<std::list<int> > {
  static const char *name(std::list<int> &stack) {
    return "std::list";
  }

  static void reset(std::list<int> &stack) {
    stack.clear();
  }

  static void push(std::list<int> &stack, int elem) {
    stack.push_front(elem);
  }

  static int pop(std::list<int> &stack) {
    int elem = stack.front();

    stack.pop_front();

    return elem;
  }

  static bool empty(std::list<int> &stack) {
    return stack.empty();
  }
};

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  std::vector<int> vectorStack;
  std::list<int> listStack;

  // Running a generic algorithm on two different stack implementation does not
  // require using a virtual table to select the right member function to
  // invoke. What we have achieved is type-polymorphism.

  buildSampleStack(vectorStack);
  visitStack(vectorStack);

  buildSampleStack(listStack);
  visitStack(listStack);

  return EXIT_SUCCESS;
}
