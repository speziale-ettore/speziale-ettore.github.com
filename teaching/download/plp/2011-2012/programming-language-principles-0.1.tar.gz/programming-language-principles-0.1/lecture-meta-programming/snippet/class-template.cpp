template
<typename Ty,
  int N>
class Foo {
  Ty bar[N];
};
