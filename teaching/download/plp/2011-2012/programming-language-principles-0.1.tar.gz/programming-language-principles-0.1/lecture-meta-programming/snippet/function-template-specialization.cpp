template <>
int bar<int, 4>() {
  return 4;
}
