template <typename Ty>
struct ErrorTraits;

template <>
struct ErrorTraits<int> {
  enum { invalidValue = -1 };
};
