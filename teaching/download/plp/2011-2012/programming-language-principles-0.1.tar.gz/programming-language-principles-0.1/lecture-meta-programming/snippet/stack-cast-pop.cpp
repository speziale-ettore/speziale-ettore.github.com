elt = *reinterpret_cast<int *>(stack.pop());
