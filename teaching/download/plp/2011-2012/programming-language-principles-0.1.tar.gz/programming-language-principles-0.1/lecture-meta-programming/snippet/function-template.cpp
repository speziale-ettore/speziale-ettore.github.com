template
<typename Ty>
void bar(Ty baz) {
  baz.hello();
}
