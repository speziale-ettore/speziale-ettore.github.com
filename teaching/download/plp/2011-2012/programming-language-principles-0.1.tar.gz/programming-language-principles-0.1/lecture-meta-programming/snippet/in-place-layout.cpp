class Foo {
  Bar bar;
};
