template <typename Ty, unsigned N>
Ty Stack<Ty, N>::pop() {
  if(top == 0)
    return ErrorTraits<Ty>::invalidValue;

  return storage[--top];
}
