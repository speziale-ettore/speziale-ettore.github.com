template
<typename Ty, int N = 16>
class Foo { Ty bar[N]; };
