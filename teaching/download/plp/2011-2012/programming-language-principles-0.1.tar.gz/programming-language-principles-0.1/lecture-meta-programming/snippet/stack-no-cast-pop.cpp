elt = stack.pop();
