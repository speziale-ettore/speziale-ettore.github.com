template <>
class Foo<char, 16> {
  char *bar;
};
