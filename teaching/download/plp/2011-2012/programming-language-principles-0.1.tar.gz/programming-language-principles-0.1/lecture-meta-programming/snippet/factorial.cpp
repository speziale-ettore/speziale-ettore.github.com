template <unsigned N>
struct fact {
  enum { value = N * fact<N - 1> };
};

template <>
struct fact<0> {
  enum { value = 1 };
};
