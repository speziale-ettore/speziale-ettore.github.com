template <typename Ty, int N>
Ty bar() {
  return Ty(N);
}
