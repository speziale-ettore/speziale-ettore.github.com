template <unsigned N>
class Foo<char, N> {
  char bar[N];
};
