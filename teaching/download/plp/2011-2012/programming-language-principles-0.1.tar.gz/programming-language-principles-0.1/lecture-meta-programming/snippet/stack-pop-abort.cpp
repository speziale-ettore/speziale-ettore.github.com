template <typename Ty, unsigned N>
Ty Stack<Ty, N>::pop() {
  if(top == 0)
    abort();

  return storage[--top];
}
