a = __builtin_shufflevector(a, a,
                            3, 2, 1, 0);
