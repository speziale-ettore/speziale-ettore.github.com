#pragma omp parallel
{ ... }
