#include <xmmintrin.h>

...

y = _mm_sqrt_ps(x);
