#pragma omp parallel for
for(i = 0; i < 10; ++i) {
  #pragma omp critical
  foo();

  #pragma omp master
  bar();

  #pragma omp barrier
  baz();
}
