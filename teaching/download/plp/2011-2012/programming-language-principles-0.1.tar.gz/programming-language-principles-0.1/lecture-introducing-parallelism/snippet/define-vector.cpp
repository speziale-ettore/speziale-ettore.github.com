typedef
__attribute__((vector_size(16)))
int64_t storage_t;
