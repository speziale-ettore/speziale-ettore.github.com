#pragma omp parallel for
for(i = 0; i < 10; ++i) {
  c[i].x = a[i].x + b[i].x;
  c[i].y = a[i].y + b[i].y;
}
