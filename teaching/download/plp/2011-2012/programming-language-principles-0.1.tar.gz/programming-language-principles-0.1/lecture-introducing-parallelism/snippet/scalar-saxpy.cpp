for(unsigned i = 0, e = n; i != n; ++i)
  y[i] += a * x[i];
