
#include <iostream>
#include <vector>

#include <cstdlib>

// Clang does not support OpenMP -- include OpenMP headers only when compiling
// with a compiler supporting OpenMP.
#ifdef HAVE_OPENMP
#include <omp.h>

// Otherwise -- e.g. with Clang -- we have to define stubs for functions we will
// use.
#else

extern "C" {

// No OpenMP, the only thread has id equal to 0.
int omp_get_thread_num() {
  return 0;
}

// No OpenMP, only one thread, the master
int omp_get_num_threads() {
  return 1;
}

}

#endif // HAVE_OPENMP

namespace plp {

template <typename Ty>
struct RandomTraits;

class Point {
public:
  Point() : x(0),
            y(0) { }

  Point(int64_t x, int64_t y) : x(x),
                                y(y) { }

public:
  bool operator==(const Point &that) const {
    return x == that.x && y == that.y;
  }

  bool operator!=(const Point &that) const {
    return !(*this == that);
  }

public:
  Point operator+(const Point &that) {
    return Point(x + that.x, y + that.y);
  }

public:
  int64_t getX() const { return x; }
  int64_t getY() const { return y; }

private:
  int64_t x;
  int64_t y;
};

template <>
struct RandomTraits<Point> {
  class random_iterator : public std::iterator<std::input_iterator_tag, Point> {
  public:
    random_iterator() : cur(0, 0),
                        last(0),
                        mod(0) { }

  private:
    random_iterator(unsigned samples) : cur(0, 0),
                                        last(samples),
                                        mod(samples) {
      advance();
    }

  public:
    bool operator==(const random_iterator &that) const {
      return (cur == that.cur && last == that.last) ||
             (last == 0 && that.last == 0);
    }

    bool operator!=(const random_iterator &that) const {
      return !(*this == that);
    }

    random_iterator &operator++() {
      advance(); return *this;
    }

    random_iterator operator++(int ign) {
      random_iterator ret(*this); advance(); return ret;
    }

    const Point &operator*() const {
      return cur;
    }

  private:
    void advance() {
      if(!last)
        return;

      // Numbers are generated modulo "mod" just to print them nicely.
      cur = Point(std::rand() % mod, std::rand() % mod);

      --last;
    }

  private:
    Point cur;

    unsigned last;
    unsigned mod;

    friend class RandomTraits<Point>;
  };

  static random_iterator random_begin(unsigned samples = 8) {
    return random_iterator(samples);
  }

  static random_iterator random_end() {
    return random_iterator();
  }
};

std::ostream &operator<<(std::ostream &os, const Point &pnt) {
  return os << "(" << pnt.getX() << "," << pnt.getY() << ")";
}

} // End namespace plp.

using namespace plp;

int main(int argc, char *argv[]) {
  std::vector<Point> as, bs;

  as.assign(RandomTraits<Point>::random_begin(),
            RandomTraits<Point>::random_end());
  bs.assign(RandomTraits<Point>::random_begin(),
            RandomTraits<Point>::random_end());

  int i, e;

  // A parallel for. All iterations will be executed in parallel, without any
  // implicit synchronization, under the assumption that there are no
  // dependencies between different iterations.
  # pragma omp parallel for
  for(i = 0; i < as.size(); ++i) {
    Point cs = as[i] + bs[i];

    // We are going to compete for a shared resource -- standard output. OpenMP
    // is not aware of this fact, so we need to explicitly define a critical
    // section to serialize accesses to standard output.
    # pragma omp critical
    std::cerr << "[Thread - "
              << omp_get_thread_num() + 1 << "/" << omp_get_num_threads()
              << ", Iteration - " << i << "]: "
              << as[i] << " + " << bs[i] << " = " << cs << std::endl;
  }

  return EXIT_SUCCESS;
}
