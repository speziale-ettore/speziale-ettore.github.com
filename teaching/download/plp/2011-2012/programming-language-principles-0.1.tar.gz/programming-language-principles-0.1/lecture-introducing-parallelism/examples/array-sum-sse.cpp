
#include <iostream>
#include <limits>
#include <vector>

#include <cstdlib>

namespace plp {

template <typename Ty>
struct RandomTraits;

class Point {
private:
  // We want to use an SSE vector to store the couple of points. For every
  // compiler there is a special syntax for declaring a type for vectors of
  // elemental types.
  typedef __attribute__((vector_size(2 * sizeof(int64_t)))) int64_t storage_t;

public:
  // Operations involving vectors are faster because the hardware makes some
  // assumptions about how operands are placed in memory. In the X86
  // architecture, vectors must be aligned to 16 byte boundaries. By re-defining
  // memory allocation routine we enforce this behaviour when 'Point' is
  // allocated in the heap.
  static void *operator new(size_t size) {
    void *addr;
    
    if(posix_memalign(&addr, 16, size))
      throw std::bad_alloc();

    return addr;
  }

  // The same must olds for arrays of 'Point's.
  static void *operator new[](size_t size) {
    return operator new(size);
  }

  // Needed by STL allocators -- see documentation about placement 'new'.
  static void *operator new(size_t size, void *ptr) throw() {
    return ptr;
  }

  // Needed by STL allocators -- see documentation about placement 'new'.
  static void *operator new[](size_t size, void *ptr) throw() {
    return ptr;
  }

  static void operator delete(void *addr) {
    std::free(addr);
  }

  static void operator delete[](void *addr) {
    operator delete(addr);
  }

public:
  Point() {
    // The vector is just a couple of 'int64_t'.
    point[0] = 0;
    point[1] = 0;
  }

  Point(int64_t x, int64_t y) {
    point[0] = x;
    point[1]= y;
  }

private:
  Point(storage_t point) : point(point) { }

public:
  bool operator==(const Point &that) const {
    storage_t diff = point - that.point;

    return diff[0] == 0 && diff[1] == 0;
  }

  bool operator!=(const Point &that) const {
    return !(*this == that);
  }

public:
  Point operator+(const Point &that) {
    // The sum between two pointers is translated by the compiler to efficient
    // SSE instructions on X86/X86_64.
    return Point(point + that.point);
  }

public:
  int64_t getX() const { return point[0]; }
  int64_t getY() const { return point[1]; }

private:
  // The compiler naturally align this fields, when placing 'Point' on the stack
  // or inside another object -- accesses to 'point' will be aligned, so no
  // segmentation faults can happens.
  storage_t point;
};

template <>
struct RandomTraits<Point> {
  class random_iterator : public std::iterator<std::input_iterator_tag, Point> {
  public:
    random_iterator() : cur(0, 0),
                        last(0),
                        mod(0) { }

  private:
    random_iterator(unsigned samples) : cur(0, 0),
                                        last(samples),
                                        mod(samples) {
      advance();
    }

  public:
    bool operator==(const random_iterator &that) const {
      return (cur == that.cur && last == that.last) ||
             (last == 0 && that.last == 0);
    }

    bool operator!=(const random_iterator &that) const {
      return !(*this == that);
    }

    random_iterator &operator++() {
      advance(); return *this;
    }

    random_iterator operator++(int ign) {
      random_iterator ret(*this); advance(); return ret;
    }

    const Point &operator*() const {
      return cur;
    }

  private:
    void advance() {
      if(!last)
        return;

      // Numbers are generated modulo "mod" just to print them nicely.
      cur = Point(std::rand() % mod, std::rand() % mod);

      --last;
    }

  private:
    Point cur;

    unsigned last;
    unsigned mod;

    friend class RandomTraits<Point>;
  };

  static random_iterator random_begin(unsigned samples = 8) {
    return random_iterator(samples);
  }

  static random_iterator random_end() {
    return random_iterator();
  }
};

std::ostream &operator<<(std::ostream &os, const Point &pnt) {
  return os << "(" << pnt.getX() << "," << pnt.getY() << ")";
}

} // End namespace plp.

using namespace plp;

namespace std {

// By specializing the 'std::allocator' template we are telling STL containers
// to use custom memory allocation routines for allocating 'Point' instances.
// This allows to correctly align them in memory.
template <>
class allocator<Point> {
public:
  typedef Point value_type;

  typedef Point * pointer;
  typedef Point & reference;

  typedef const Point * const_pointer;
  typedef const Point & const_reference;

  typedef size_t size_type;
  typedef ptrdiff_t difference_type;

  template <class U>
  struct rebind {
    typedef allocator<U> other;
  };

public:
  Point *address(Point &pnt) {
    return &pnt;
  }

  const Point *address(const Point &pnt) const {
    return &pnt;
  }

public:
  Point *allocate(size_t n, const void *hint = NULL) {
    return new Point[n];
  }

  void deallocate(Point *pnt, size_t n) {
    delete [] pnt;
  }

public:
  size_t max_size() const throw() {
    return numeric_limits<size_t>::max();
  }

public:
  void construct(Point *pnt, const Point &that) {
    new (reinterpret_cast<void *>(pnt)) Point(that);
  }

  void destroy(Point *pnt) {
    pnt->~Point();
  }
};

} // End namespace std.

int main(int argc, char *argv[]) {
  std::vector<Point> as, bs;

  as.assign(RandomTraits<Point>::random_begin(),
            RandomTraits<Point>::random_end());
  bs.assign(RandomTraits<Point>::random_begin(),
            RandomTraits<Point>::random_end());

  for(unsigned i = 0, e = as.size(); i != e; ++i) {
    Point cs = as[i] + bs[i];

    std::cerr << as[i] << " + " << bs[i] << " = " << cs << std::endl;
  }

  return EXIT_SUCCESS;
}
