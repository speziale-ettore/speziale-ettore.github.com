
#include <iostream>
#include <tr1/memory>
#include <vector>

#include <cstdlib>

#define unreachable()                        \
  do {                                       \
    std::cerr << "Unreachable" << std::endl; \
    abort();                                 \
  } while(0)

namespace plp {

template <typename Ty>
struct RandomTraits;

template <>
struct RandomTraits<float> {
  class random_iterator : public std::iterator<std::input_iterator_tag, float> {
  public:
    random_iterator() : cur(0.0),
                        last(0) { }

  private:
    random_iterator(unsigned samples) : cur(0.0),
                                        last(samples) {
      advance();
    }

  public:
    bool operator==(const random_iterator &that) const {
      return (cur == that.cur && last == that.last) ||
             (last == 0 && that.last == 0);
    }

    bool operator!=(const random_iterator &that) const {
      return !(*this == that);
    }

    random_iterator &operator++() {
      advance(); return *this;
    }

    random_iterator operator++(int ign) {
      random_iterator ret(*this); advance(); return ret;
    }

    const float &operator*() const {
      return cur;
    }

  private:
    void advance() {
      if(!last)
        return;

      cur = std::rand();

      --last;
    }

  private:
    float cur;
    unsigned last;

    friend class RandomTraits<float>;
  };

  static random_iterator random_begin(unsigned samples = 16 * 1024 * 1024) {
    return random_iterator(samples);
  }

  static random_iterator random_end() {
    return random_iterator();
  }
};

// Simple sharing pointer for arrays. It extends 'std::tr1::shared_ptr', by
// injecting a custom deleter.
template <typename Ty>
class array_ptr : public std::tr1::shared_ptr<Ty> {
private:
  class deleter {
  public:
    void operator()(Ty *ptr) { delete [] ptr; }
  };

public:
  array_ptr(Ty *ptr) : std::tr1::shared_ptr<Ty>(ptr, deleter()) { }
};

enum Container {
  Array,
  Vector
};

enum Kernel {
  Base,
  SSE,
  OpenMP
};

std::ostream &operator<<(std::ostream &os, enum Container cnt);
std::ostream &operator<<(std::ostream &os, enum Kernel kern);

class StopWatch {
public:
  StopWatch(enum Container cnt,
            enum Kernel kern,
            std::ostream &os = std::cerr) : os(os) {
    os << "Benchmark " << cnt << "/" << kern << std::endl;

    start = readTime();
  }

  ~StopWatch() {
    os << "  Time: " << (readTime() - start) << " ns" << std::endl;
  }

private:
  uint64_t readTime() {
    struct timespec ts;

    clock_gettime(CLOCK_REALTIME, &ts);

    // Use 1000000000 instead of 1.0e-9 to avoid type promotion.
    return uint64_t(ts.tv_sec) * 1000000000 + uint64_t(ts.tv_nsec);
  }

private:
  std::ostream &os;
  uint64_t start;
};

template <enum Container cnt, enum Kernel kern, typename IterTy>
void runSAXPY(IterTy y, float a, IterTy x, unsigned n);

// Scalar version of SAXPY. Elements are fetched one-by-one from memory. Cache
// is used to fetch data from memory.
template <>
void runSAXPY<Array, Base>(float *y,
                           float a,
                           float *x,
                           unsigned n) {
  StopWatch watch(Array, Base);

  for(unsigned i = 0, e = n; i != n; ++i)
    y[i] += a * x[i];
}

// Scalar version of SAXPY, but data is stored in a vector. We can observe the
// same behaviour of the previous version.
template <>
void runSAXPY<Vector, Base>(std::vector<float>::iterator y,
                            float a,
                            std::vector<float>::iterator x,
                            unsigned n) {
  StopWatch watch(Vector, Base);

  for(unsigned i = 0, e = n; i != n; ++i)
    y[i] += a * x[i];
}

// Vectorized version of SAXPY. Data is fetched in block of 4 floats, without
// passing from the cache.
template <>
void runSAXPY<Array, SSE>(float *y,
                          float a,
                          float *x,
                          unsigned n) {
  uintptr_t yStart = reinterpret_cast<uintptr_t>(y),
            xStart = reinterpret_cast<uintptr_t>(x),

            yEnd = yStart + n * sizeof(float),
            xEnd = xStart + n * sizeof(float);

  if(yStart % 16 != 0 || xStart % 16 != 0)
    unreachable();

  StopWatch watch(Array, SSE);

  typedef __attribute__((vector_size(4 * sizeof(float)))) float sse_float_t;

  sse_float_t *sseY = reinterpret_cast<sse_float_t *>(y),
              *sseX = reinterpret_cast<sse_float_t *>(x);

  sse_float_t sseA = { a, a, a, a };

  for(unsigned i = 0, e = n / 4; i != e; ++i)
    sseY[i] += sseA * sseX[i];
  
  for(unsigned i = n - n % 4, e = n; i != e; ++i)
    y[i] += a * x[i];
}

// OpenMP version of SAXPY. Iterations are equally split among available
// workers.
template <>
void runSAXPY<Array, OpenMP>(float *y,
                             float a,
                             float *x,
                             unsigned n) {
  StopWatch watch(Array, OpenMP);

  #pragma omp parallel for
  for(int i = 0; i < n; ++i)
    y[i] += a * x[i] + y[i];
}

} // End namespace plp.

void *operator new[](size_t size, size_t align) {
  void *addr;
  
  if(posix_memalign(&addr, align, size))
    throw std::bad_alloc();

  return addr;
}

using namespace plp;

int main(int argc, char *argv[]) {
  std::vector<float> yInput(RandomTraits<float>::random_begin(),
                            RandomTraits<float>::random_end());
  std::vector<float> xInput(RandomTraits<float>::random_begin(),
                            RandomTraits<float>::random_end());

  float a = *RandomTraits<float>::random_begin(1);
  unsigned n = yInput.size();

  array_ptr<float> yArr(new float[n]);
  array_ptr<float> xArr(new float[n]);

  std::vector<float> yVect;
  std::vector<float> xVect;

  array_ptr<float> yAlignedArr(new (16) float[n]);
  array_ptr<float> xAlignedArr(new (16) float[n]);

  std::copy(yInput.begin(), yInput.end(), yArr.get());
  std::copy(xInput.begin(), xInput.end(), xArr.get());

  yVect = yInput;
  xVect = xInput;

  std::copy(yInput.begin(), yInput.end(), yAlignedArr.get());
  std::copy(xInput.begin(), xInput.end(), xAlignedArr.get());

  runSAXPY<Array, Base>(yArr.get(), a, xArr.get(), n);
  runSAXPY<Vector, Base>(yVect.begin(), a, xVect.begin(), n);
  runSAXPY<Array, SSE>(yAlignedArr.get(), a, xAlignedArr.get(), n);
  runSAXPY<Array, OpenMP>(yAlignedArr.get(), a, xAlignedArr.get(), n);

  return EXIT_SUCCESS;
}

std::ostream &plp::operator<<(std::ostream &os, enum Container cnt) {
  #define CONTAINER(C, N)   \
    case C: return os << N; \

  switch(cnt) {
  CONTAINER(Array, "[]")
  CONTAINER(Vector, "std::vector")

  default:
    unreachable();
  }

  #undef CONTAINER
}

std::ostream &plp::operator<<(std::ostream &os, enum Kernel kern) {
  #define KERNEL(C, N)      \
    case C: return os << N; \

  switch(kern) {
  KERNEL(Base, "base")
  KERNEL(SSE, "sse")
  KERNEL(OpenMP, "OpenMP")

  default:
    unreachable();
  }

  #undef KERNEL
}
