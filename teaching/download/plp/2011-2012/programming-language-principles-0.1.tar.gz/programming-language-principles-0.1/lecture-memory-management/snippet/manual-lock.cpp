void Bar::mutual() {
  lock.acquire();
  lock.release();
}
