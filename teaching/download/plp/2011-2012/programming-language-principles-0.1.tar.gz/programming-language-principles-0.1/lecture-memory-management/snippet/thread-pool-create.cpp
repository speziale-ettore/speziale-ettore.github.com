Thread &Thread::get() {
  if(pool.empty()) {
    return *(new Thread());

  Thread *thr = pool.back();
  pool.pop_back();

  return *thr;
}
