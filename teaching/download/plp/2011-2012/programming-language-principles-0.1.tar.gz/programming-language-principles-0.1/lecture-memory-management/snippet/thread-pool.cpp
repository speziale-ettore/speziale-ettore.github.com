class Thread {
public:
  static Thread &get();
  static void put(Thread &thr);

private:
  static std::vector<Thread *> pool;
};
