int foo() {
  std::auto_arr_ptr<int> buf;
  int ret

  buf.reset(new int[HUGE]);

  ...

  return ret;
}
