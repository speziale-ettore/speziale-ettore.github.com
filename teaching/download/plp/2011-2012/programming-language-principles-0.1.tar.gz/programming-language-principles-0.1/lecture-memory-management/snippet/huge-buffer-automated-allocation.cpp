int foo() {
  Buffer<int> buf;
  int ret

  ...

  return ret;
}
