void foo() {
  Baz baz;
  int bar;
}
