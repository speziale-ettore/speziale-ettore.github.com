void Bar::mutual() {
  Sync sync(lock);
}
