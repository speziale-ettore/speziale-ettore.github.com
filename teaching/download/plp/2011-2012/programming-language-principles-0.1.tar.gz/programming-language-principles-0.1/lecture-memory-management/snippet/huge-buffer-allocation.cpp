int foo() {
  int *buf, ret;
  
  buf = new int[HUGE];

  ...

  delete [] buf;

  return ret;
}
