template <typename Ty>
class Allocator {
public:
  static void *operator new(size_t size);
  static void operator delete(void *addr);

private:
  static std::vector<Ty *> pool;
};
