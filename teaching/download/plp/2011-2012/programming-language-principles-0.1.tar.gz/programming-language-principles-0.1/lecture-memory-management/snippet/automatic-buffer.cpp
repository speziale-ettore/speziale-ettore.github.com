template <typename Ty>
class Buffer {
public:
  Buffer(size_t size = HUGE) :
    buf(new Ty[size]) { }

  ~Buffer() { delete [] buf; }

private:
  Ty *buf;
};
