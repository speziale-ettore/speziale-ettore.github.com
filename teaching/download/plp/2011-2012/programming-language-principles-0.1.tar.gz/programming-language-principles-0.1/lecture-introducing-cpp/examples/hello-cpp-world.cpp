
// The iostream library allows to interact with streams -- flows of bytes. In
// the iostream header file three important streams are defined: std::cin
// (standard input), std::cout (standard output) and std::cerr (standard error).

#include <iostream>

#include <cstdlib>

// In the context of streams, the '<<' operator assumes the meaning of 'insert
// operator': 'a << b' is insert variable 'b' into stream 'a'.

int main(int argc, char *argv[]) {
  std::cout << "Hello, world!" << std::endl;

  return EXIT_SUCCESS;
}
