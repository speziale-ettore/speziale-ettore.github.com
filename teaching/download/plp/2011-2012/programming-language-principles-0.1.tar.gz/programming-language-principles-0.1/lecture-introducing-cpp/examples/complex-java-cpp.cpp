
#include <string>

#include <cstdio>
#include <cstdlib>

// It is better to put all your code, except main, in a namespace.
namespace plp {

class Complex {
public:
  // Object initialization in C++ is performed using a custom syntax, before
  // constructor body -- interpreted as 'invoking constructors of 'this->r' and
  // 'this->i', passing 'r' and 'i' as arguments.
  Complex(int r, int i) : r(r), i(i) { }

public:
  // You can use references to pass objects by address. With respect to
  // pointers, references can be assigned only once. Usually, passing a
  // parameter using a pointer means that called function gets the ownership of
  // the value pointed -- it is in charge of freeing it. If a parameter is
  // passed by reference, this means the caller is not giving to a function the
  // ownership of the parameter.
  //
  // C++ allows to overload operators. In this case, instead of writing an add
  // function is better to overload the '+' operator for class 'Complex'.
  // Usually an overloaded operator does not modify the state of an object.
  // Instead, it creates a new object. Moreover, the new object is returned
  // by-copy. Not all operators can be overloaded.
  Complex operator+(Complex &that) {
    Complex c(r + that.r, i + that.i);

    return c;
  }

  // Here we declare a member function, without giving its body. If we give
  // member function definition together with its declaration, the compiler
  // automatically in-line the code. This is often useful if the size of the
  // member function is small, otherwise is better to define the member function
  // out-of-line, preventing in-lining.
  std::string toString();

private:
  int r;
  int i;
};

} // End namespace plp.

// It is better to import your top namespace, and not to import namespaces
// defined by used libraries.
using namespace plp;

std::string Complex::toString() {
  std::string asString;

  // It's still ugly! We miss something.
  asString.push_back('(');
  asString.push_back((char) (r + 48));
  asString.push_back(',');
  asString.push_back((char) (i + 48));
  asString.push_back(')');

  return asString;
}

int main(int argc, char *argv[]) {
  // In C++ stack is used more often than that in Java. This because by default
  // there isn't a memory allocation mechanism, so in order to avoid using
  // 'new/delete' stack allocation is preferred. In order to improve the
  // efficiency of this approach, other techniques are used.
  Complex c1(1, 1);
  std::string asString1(c1.toString());

  // The std::string::c_str() member function allows to get a C version of a C++
  // string.
  std::printf("Complex number is: %s\n", asString1.c_str());

  Complex c2(1, 1);
  c2 = c1 + c2;
  std::string asString2(c2.toString());

  // The std::string::c_str() member function allows to get a C version of a C++
  // string.
  std::printf("Complex number is: %s\n", asString2.c_str());

  return EXIT_SUCCESS;
}
