
#include <iostream>
#include <string>

#include <cstdlib>

// It is better to put all your code, except main, in a namespace.
namespace plp {

class Complex {
public:
  // Object initialization in C++ is performed using a custom syntax, before
  // constructor body -- interpreted as 'invoking constructors of 'this->r' and
  // 'this->i', passing 'r' and 'i' as arguments.
  Complex(int r, int i) : r(r), i(i) { }

public:
  // You can use references to pass objects by address. With respect to
  // pointers, references can be assigned only once. Usually, passing a
  // parameter using a pointer means that called function gets the ownership of
  // the value pointed -- it is in charge of freeing it. If a parameter is
  // passed by reference, this means the caller is not giving to function the
  // ownership of the parameter.
  //
  // C++ allows to overload operators. In this case, instead of writing an 'add'
  // function is better to overload the '+' operator for class 'Complex'.
  // Usually an overloaded operator does not modify the state of an object.
  // Instead, it creates a new object. Moreover, the new object is returned
  // by-copy. Not all operators can be overloaded.
  Complex operator+(Complex &that) {
    Complex c(r + that.r, i + that.i);

    return c;
  }

  // The toString method is used in Java to get a string representation of an
  // object, used for debug purpose. There isn't such tradition in C++. A good
  // programming practice is to define a dump method used to write the class to
  // standard error. Out-of-line defining allows this member function to be
  // called from gdb.
  void dump();

private:
  int r;
  int i;

  // By declaring the 'std::ostream &plp::operator<<(std::ostream &, Complex &)'
  // function friend of Complex class, we allow it accessing Complex protected
  // and private members. The 'plp' namespace is implicitly added -- God bless
  // C++ scoping rules.
  friend std::ostream &operator<<(std::ostream &, Complex &);
};

} // End namespace plp.

// It is better to import your top namespace, and not to import namespaces
// defined by used libraries.
using namespace plp;

// In C (and UNIX) a key abstraction is the file. Many things are performed
// using files: I/O, mapping memory, talking with devices, ... . In C++ this
// concept is enhanced. Files is replaced by streams. There are streams for
// writing to files and also for building strings. Key concepts about streams
// are the 'insert' and the 'extract' operators. The 'insert' operator allows to
// put an object into a stream, while the 'extract' operator allows to get an
// object from a stream. The 'insert' operator is implemented by overloading the
// '<<' operator, while the 'extract' operator is implemented by overloading the
// '>>' operator. The 'std::cerr' stream represents standard error. Thus for
// dumping a 'Complex' object into standard error we simply put a reference
// inside 'std::cerr' -- a call to the function overloading the operator '<<'
// for objects of class 'std::ostream' (output stream) and 'Complex' is emitted
// by the compiler.
void Complex::dump() {
  std::cerr << *this << std::endl;
}

// Since '<<' is an operator, we must define a function with a special name for
// overloading the '<<' operator. Given the expression 'a op b', where 'a' is of
// type 'A', 'op' is an operator, and 'b' is of type 'B', is it possible to
// overload 'op' by either defining:
// 1) a special member function inside class 'A' -- see the overload of '+' for
//    'Complex'. The first operand is 'a', implicitly passed using 'this'.
// 2) a special function with two explicit operand, 'a' and 'b'.
//
// The first method can be used when you can modify the sources defining class
// 'A', so you can add a member function overloading the operator. In the case
// where you cannot modify the definition of the class -- this case -- you have
// to use the second method. Obviously the second method must be used also when
// overloading operators whose first operand isn't a class.
//
// Notice the namespace name used to disambiguate function definition -- C++
// scoping rules are a nightmare.
std::ostream &plp::operator<<(std::ostream &os, Complex &c) {
  // This is C++! Streams allows to perform formatted output without using
  // format strings. Output streams are chained -- see comment below.
  // Notice that we are accessing to private members of 'c' ('r' and 'i'). This
  // is possible because this function has been declared friend of class
  // 'Complex', so access restriction rules are not applied.
  os << '(' << c.r << ',' << c.i << ')';

  // Must be possible chaining streams using the '<<' operator, so that function
  // must return a reference to a stream, usually the stream where we have
  // inserted the object.
  return os;
}

int main(int argc, char *argv[]) {
  // In C++ stack is used more often than that in Java. This because by default
  // there isn't a memory allocation mechanism, so in order to avoid using
  // 'new/delete' stack allocation is preferred. In order to improve the
  // efficiency of this approach, other techniques are used.
  Complex c1(1, 1);

  // Using streams printing things is easier. The 'std::endl' is a manipulator.
  // A manipulator inserted into a stream interacts with the stream. There are
  // different manipulators. The 'std::endl' simply print a newline and flush
  // the stream.
  std::cout << "Complex number is: " << c1 << std::endl;

  Complex c2(1, 1);
  c2 = c1 + c2;

  std::cout << "Complex number is: " << c2 << std::endl;

  return EXIT_SUCCESS;
}
