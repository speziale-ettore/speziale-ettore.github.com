
#include <string>

#include <cstdio>
#include <cstdlib>

// It is better to put all your code, except main, in a namespace.
namespace plp {

class Complex {
public:
  Complex(int r, int i) {
    // this is a pointer, not a reference (like in Java) -- you have to use '->'
    // instead of '.'.

    this->r = r;
    this->i = i;
  }

public:
  void add(Complex *that) {
    r += that->r;
    i += that->i;
  }

  std::string *toString() {
    std::string *asString = new std::string();

    // This code looks ugly -- maybe because this is the Java-way, not the
    // C++-way.
    asString->push_back('(');
    asString->push_back((char) (r + 48));
    asString->push_back(',');
    asString->push_back((char) (i + 48));
    asString->push_back(')');

    return asString;
  }

private:
  int r;
  int i;
};

} // End namespace plp.

// It is better to import your top namespace, and not to import namespaces
// defined by used libraries.
using namespace plp;

int main(int argc, char *argv[]) {
  // In C++ there aren't Java-like references. If you need to allocate an object
  // in the heap, you have to play with pointers.
  Complex *c1 = new Complex(1, 1);
  std::string *asString1 = c1->toString();

  // The std::string::c_str() member function allows to get a C version of a C++
  // string.
  std::printf("Complex number is: %s\n", asString1->c_str());

  Complex *c2 = new Complex(1, 1);
  c2->add( c1 );
  std::string *asString2 = c2->toString();

  // The std::string::c_str() member function allows to get a C version of a C++
  // string.
  std::printf("Complex number is: %s\n", asString2->c_str());

  // By default, in C++ there isn't automatic memory management, you have to
  // free allocated resources by hand.
  delete asString2;
  delete c2;
  delete asString1;
  delete c1;

  return EXIT_SUCCESS;
}
