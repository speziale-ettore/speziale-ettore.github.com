
// This is a C++ hello world. Key concept is that C++ is based on C, so it can
// compile a large number of C programs.

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
  printf("Hello, world!\n");

  return EXIT_SUCCESS;
}
