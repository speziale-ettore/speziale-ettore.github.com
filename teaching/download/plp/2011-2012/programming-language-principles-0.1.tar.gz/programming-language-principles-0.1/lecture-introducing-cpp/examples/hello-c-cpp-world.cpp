
// C standard library is part of C++ standard library. Header files for that
// library are slightly different: get a 'c' prefix, loose the '.h' trailer.

#include <cstdio>
#include <cstdlib>

// All functions/types/objects declared in the C++ standard library are put in
// the std namespace. Namespace are containers for 'things', and can be nested.

int main(int argc, char *argv[]) {
  std::printf("Hello, world!\n");

  return EXIT_SUCCESS;
}
