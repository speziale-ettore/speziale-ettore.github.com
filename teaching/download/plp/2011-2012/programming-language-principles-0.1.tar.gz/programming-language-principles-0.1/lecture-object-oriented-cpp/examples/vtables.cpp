
#include <iostream>
#include <string>

#include <cstdlib>

namespace plp {

class Person {
public:
  Person(const char *name) : name(name) { }

public:
  // Person is a root class. It defines a virtual table, where virtual member
  // functions pointer are stored.
  virtual std::string getName() { return name; }

private:
  std::string name;
};

class Student : public Person {
public:
  Student(const char *name) : Person(name) { }

public:
  // Student inherits from Person, so it will inherits Person virtual table. The
  // virtual table is used for storing virtual member functions defined by
  // Student. Since every instance of student should be used in place of a
  // Person, pointers to virtual member functions are appended to the virtual
  // table.
  virtual void doExam() {
    std::cout << "Thinking: done" << std::endl;
    std::cout << "Writing solution: done" << std::endl;
  }
};

class PhDStudent : public Student {
public:
  PhDStudent(const char *name) : Student(name) { }

public:
  // This virtual member function is overrided, there is no need to reserve a
  // new slot in the virtual table. The slot coming from "plp::Student" must be
  // overwritten in order to contain the address of "plp::PhDStudent::doExam".
  virtual void doExam() {
    std::cout << "Thinking: done" << std::endl;
    std::cout << "Writing problem: done" << std::endl;
  }
};

class StateEmployee {
public:
  StateEmployee(unsigned id) : id(id) { }

public:
  // State employee is a root class. It defines a virtual member function, so a
  // virtual table is generated.
  virtual unsigned getId() { return id; }

private:
  unsigned id;
};

// This class derives from two base classes. Both of them, defines virtual
// methods thus, two virtual tables are inherited by "plp::Professor".
class Professor : public PhDStudent, public StateEmployee {
public:
  Professor(const char *name, unsigned id) : PhDStudent(name),
                                             StateEmployee(id) { }

public:
  // Overriding of "plp::Student::getName", the corresponding slot of the
  // virtual table of "plp::PhDStudent" has to be overwritten.
  virtual std::string getName() {
    return "Professor " + PhDStudent::getName();
  }

  // New member function, a virtual table is required for holding its pointer.
  // However, there is a problem: "plp::Professor" derives from two classes,
  // thus it has two different virtual tables. In my setup "clang-3.0,x86,linux"
  // the compiler uses the first virtual table, that is the one of
  // "plp::PhDStudent".
  virtual void advise(PhDStudent &student) {
    std::cerr << "Advising " << student.getName() << ": done" << std::endl;
  }
};

} // End namespace plp.

using namespace plp;

void printInstructions();

int main(int argc, char *argv[]) {
  Student student( "Marcello" );
  PhDStudent phDStudent( "Michele" );
  StateEmployee employee( 123 );
  Professor professor( "Stefano", 456 );

  printInstructions();

  return EXIT_SUCCESS;
}

void printInstructions() {
  std::cout << "### Instructions"                              << std::endl
            << " - Run this program with gdb: 'gdb ./vtables'" << std::endl
            << " - Break here: 'break vtables.cpp:101'"        << std::endl
            << " - Look at virtual tables: 'p X._vptr$Y[N]'"   << std::endl
                                                               << std::endl

            << "### Legend"                << std::endl
            << " - X: object to inspect"   << std::endl
            << " - Y: class VT to inspect" << std::endl
            << " - N: VT slot to inspect"  << std::endl;
}
