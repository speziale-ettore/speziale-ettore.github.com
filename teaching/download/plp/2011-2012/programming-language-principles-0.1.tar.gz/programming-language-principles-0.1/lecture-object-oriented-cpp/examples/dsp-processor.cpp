
#include <iostream>
#include <string>

#include <cstdlib>

namespace plp {

class Register {
public:
  Register(const char *name) : name(name) { }

private:
  std::string name;
};

class Instruction {
public:
  Instruction(const char *name) : name(name) { }

  // Later we need to do some runtime type-checking. In order to do this, type
  // information must be provided by the compiler. In order to do that, it is
  // necessary to generate a virtual table for the class of the object to cast.
  // If that class does not have any virtual method, the default trick is to
  // define an empty virtual destructor, just to force compiler emitting the
  // virtual table.
  virtual ~Instruction() { }

public:
  std::string &getName() { return name; }

private:
  std::string name;
};

class UnaryInstruction : public Instruction {
public:
  UnaryInstruction(const char *name) : Instruction(name) { }
};

class TernaryInstruction : public Instruction {
public:
  TernaryInstruction(Register out,
                     Register inA,
                     Register inB,
                     const char *name) :
    Instruction(name),
    out(out),
    inA(inA),
    inB(inB) { }

private:
  Register out;
  Register inA;
  Register inB;
};

class Add : public TernaryInstruction {
public:
  Add(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "add") { }
};

class Sub : public TernaryInstruction {
public:
  Sub(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "sub") { }
};

class FFT : public TernaryInstruction {
public:
  FFT(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "fft") { }
};

class Shuffle : public TernaryInstruction {
public:
  Shuffle(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "shuffle") { }
};

class Halt : public UnaryInstruction {
public:
  Halt() : UnaryInstruction("halt") { }
};

class Processor {
public:
  static Register R0;
  static Register R1;
  static Register R2;
  static Register R3;

public:
  Processor(const char *name) : name(name) { }

public:
  // Instead of creating a method for each instruction, we can write a method
  // dispatcher. Here there are not target methods, since this processor does
  // not implement any instruction. Moreover, we want this method to be
  // implemented by subclasses -- make it abstract!
  virtual Processor &operator<<(Instruction &instr) = 0;

public:
  std::string &getName() { return name; }

protected:
  Processor &notImplemented(Instruction &instr) {
    std::cerr << getName() << ": "
              << instr.getName() << " not implemented"
              << std::endl;

    return *this;
  }

private:
  std::string name;
};

class RISCProcessor : public Processor {
public:
  RISCProcessor(const char *name) : Processor(name) { }

  // This processor implements different instructions. This is the right place
  // where the dispatcher must be coded.
  virtual Processor &operator<<(Instruction &instr) {
    // Macros can be used to easily build dispatchers. In C++ there are 5
    // casting operators. The dynamic_cast operator is the equivalent of the
    // Java instanceof operator. On failure, NULL is returned. Please notice
    // that the cast is performed at runtime!
    #define INSTR(I)                          \
    if(I *casted = dynamic_cast<I *>(&instr)) \
      return operator<<(*casted);

    INSTR(Add)
    INSTR(Sub)
    INSTR(Halt)

    #undef INSTR

    return notImplemented(instr);
  }

  // This method is replicated for teaching purposes.
  void dump();

protected:
  Processor &operator<<(Add &add) {
    return dumpInstruction(add);
  }

  Processor &operator<<(Sub &sub) {
    return dumpInstruction(sub);
  }

  Processor &operator<<(Halt &halt) {
    return dumpInstruction(halt);
  }

  Processor &dumpInstruction(Instruction &instr) {
    std::cerr << getName() << ": " << instr.getName() << std::endl;

    return *this;
  }
};

std::ostream &operator<<(std::ostream &os, RISCProcessor &proc);

class DSPProcessor {
public:
  static Register X0;
  static Register X1;
  static Register X2;
  static Register X3;

public:
  DSPProcessor(Processor &master) : master(master) { }

protected:
  DSPProcessor &operator<<(FFT &fft) {
    return dumpInstruction(fft);
  }

  DSPProcessor &operator<<(Shuffle &shuffle) {
    return dumpInstruction(shuffle);
  }

private:
  DSPProcessor &dumpInstruction(Instruction &instr) {
    std::cerr << master.getName() << ": " << instr.getName() << std::endl;

    return *this;
  }

private:
  Processor &master;
};

// C++ supports multiple inheritance. This allows to build more complex
// inheritance structures, but at the cost of requiring more knowledge to the
// programmer. A standard "idiom" is to have a main inheritance line
// (Processor -- RISCProcessor -- CISCProcessor) and a secondary inheritance
// line (DSPProcessor -- CISCProcessor). The goal of the main line is to
// implement the majority of the functionalities, while the secondary line is
// used to implement extra functionalities and to exploit code-reusing.
class CISCProcessor : public RISCProcessor, public DSPProcessor {
public:
  // With multiple inheritance you are required to call constructors of all
  // super-classes. For the DSPProcessor constructor, an ambiguity arises (try
  // to comment out the cast). In order to resolve the ambiguity, it is
  // necessary to force considering "this" as a "RISCProcessor". Since we know
  // the cast always succeed, and that casted types are compatible, we can do it
  // at compile-time, using "static_cast".
  CISCProcessor(const char *name) :
    RISCProcessor(name),
    DSPProcessor(*static_cast<RISCProcessor *>(this)) { }

public:
  // The "CISCProcessor" supports more instructions than the "RISCProcessor". It
  // make sense to re-define the dispatcher, reusing instruction implementations
  // coming from super-classes. But there is a problem ... 
  virtual Processor &operator<<(Instruction &instr) {
    // ... instructions are handled using member functions with the same name!
    // The compiler addresses the ambiguity by implementing a simple heuristic:
    // use "operator<<" member function available in the current scope --
    // "CISCProcessor" class definition. This results into infinite recursive
    // call of the same function! In order to help the compiler we have to
    // suggest him which version of "operator<<" to use. For RISC instructions,
    // we can use the one coming from "RISCProcessor" ...
    #define INSTR(I)                            \
    if(I *casted = dynamic_cast<I *>(&instr)) { \
      RISCProcessor::operator<<(*casted);       \
      return *this;                             \
    }

    INSTR(Add)
    INSTR(Sub)
    INSTR(Halt)

    #undef INSTR

    // .. for DSP instructions, we can refer to the ones defined by
    // "DSPProcessor".
    #define INSTR(I)                            \
    if(I *casted = dynamic_cast<I *>(&instr)) { \
      DSPProcessor::operator<<(*casted);        \
      return *this;                             \
    }

    INSTR(FFT)
    INSTR(Shuffle)

    #undef INSTR

    return notImplemented(instr);
  }

  // This method is replicated for teaching purposes.
  void dump();
};

std::ostream &operator<<(std::ostream &os, CISCProcessor &proc);

void Simulate(Processor &proc);

} // End namespace plp.

using namespace plp;

Register Processor::R0("R0");
Register Processor::R1("R1");
Register Processor::R2("R1");
Register Processor::R3("R1");

Register DSPProcessor::X0("X0");
Register DSPProcessor::X1("X1");
Register DSPProcessor::X2("X1");
Register DSPProcessor::X3("X1");

void RISCProcessor::dump() {
  std::cerr << *this << std::endl;
}

std::ostream &plp::operator<<(std::ostream &os, RISCProcessor &proc) {
  os << "Size of " << proc.getName() << ": " << sizeof(RISCProcessor);

  return os;
}

void CISCProcessor::dump() {
  std::cerr << *this << std::endl;
}

std::ostream &plp::operator<<(std::ostream &os, CISCProcessor &proc) {
  os << "Size of " << proc.getName() << ": " << sizeof(CISCProcessor);

  return os;
}

int main(int argc, char *argv[]) {
  CISCProcessor p1("P1");
  RISCProcessor p2("P2");

  Simulate(p1);
  std::cout << std::endl;
  Simulate(p2);

  std::cout << std::endl << "Statistics" << std::endl;
  p1.dump();
  p2.dump();

  return EXIT_SUCCESS;
}

void plp::Simulate(Processor &proc) {
  std::cout << proc.getName() << " Simulation Start" << std::endl;

  Add add(Processor::R1, Processor::R2, Processor::R3);
  Sub sub(Processor::R3, Processor::R0, Processor::R1);
  FFT fft(DSPProcessor::X1, DSPProcessor::X2, DSPProcessor::X3);
  Shuffle shuffle(DSPProcessor::X3, DSPProcessor::X1, DSPProcessor::X0);
  Halt halt;

  proc << add
       << sub
       << fft
       << shuffle
       << halt;

  std::cout << proc.getName() << " Simulation End" << std::endl;
}
