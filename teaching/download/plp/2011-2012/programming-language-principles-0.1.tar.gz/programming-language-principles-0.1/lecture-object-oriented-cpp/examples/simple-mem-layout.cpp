
#include <iostream>

#include <cstdlib>

namespace plp {

class Big {
public:
  void dump();

private:
  char a;
  int b;
  char c;

  friend std::ostream &operator<<(std::ostream &, Big &);
};

std::ostream &operator<<(std::ostream &os, Big &big);

class Compact {
public:
  void dump();

private:
  char a;
  char c;
  int b;

  friend std::ostream &operator<<(std::ostream &, Compact &);
};

std::ostream &operator<<(std::ostream &os, Compact &comp);

// C++ have 5 different cast operators. The "reinterpret_cast" operator allows
// to cast a variable of a given type into a radically different type. Cast
// correctness must be guarantee by the programmer.
inline ptrdiff_t Offset(void *a, void *b) {
  return reinterpret_cast<uintptr_t>(a) - reinterpret_cast<uintptr_t>(b);
}

} // End namespace plp.

using namespace plp;

void Big::dump() {
  std::cerr << *this;
}

std::ostream &plp::operator<<(std::ostream &os, Big &big) {
  os << "### Big class layout ###" << std::endl
     << "  char a      = "   << Offset(&big.a, &big)
     << " bytes after base " << std::endl

     << "  int b       = "   << Offset(&big.b, &big)
     << " bytes after base " << std::endl

     << "  char c      = "   << Offset(&big.c, &big)
     << " bytes after base " << std::endl

     << "  sizeof(Big) = "   << sizeof(Big)
     << " bytes "            << std::endl;

  return os;
}

void Compact::dump() {
  std::cerr << *this;
}

std::ostream &plp::operator<<(std::ostream &os, Compact &comp) {
  os << "### Compact class layout ###" << std::endl
     << "  char a          = " << Offset(&comp.a, &comp)
     << " bytes after base "   << std::endl

     << "  char c          = " << Offset(&comp.c, &comp)
     << " bytes after base "   << std::endl

     << "  int b           = " << Offset(&comp.b, &comp)
     << " bytes after base "   << std::endl

     << "  sizeof(Compact) = " << sizeof(Compact)
     << " bytes "              << std::endl;

  return os;
}

int main(int argc, char *argcv[]) {
  Big big;
  Compact comp;

  big.dump();
  comp.dump();

  return EXIT_SUCCESS;
}  
