
#include <iostream>
#include <string>
#include <vector>

#include <cstdlib>

namespace plp {

class Register {
public:
  Register(const char *name) : name(name) { }

private:
  std::string name;
};

class Instruction {
public:
  Instruction(const char *name) : name(name) { }

  virtual ~Instruction() { }

public:
  std::string &getName() { return name; }

private:
  std::string name;
};

class UnaryInstruction : public Instruction {
public:
  UnaryInstruction(const char *name) : Instruction(name) { }
};

class TernaryInstruction : public Instruction {
public:
  TernaryInstruction(Register out,
                     Register inA,
                     Register inB,
                     const char *name) :
    Instruction(name),
    out(out),
    inA(inA),
    inB(inB) { }

private:
  Register out;
  Register inA;
  Register inB;
};

class Add : public TernaryInstruction {
public:
  Add(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "add") { }
};

class Sub : public TernaryInstruction {
public:
  Sub(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "sub") { }
};

class FFT : public TernaryInstruction {
public:
  FFT(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "fft") { }
};

class Shuffle : public TernaryInstruction {
public:
  Shuffle(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "shuffle") { }
};

class Trap : public UnaryInstruction {
public:
  Trap() : UnaryInstruction("trap") { }
};

class Halt : public UnaryInstruction {
public:
  Halt() : UnaryInstruction("halt") { }
};

class Program {
public:
  // An iterator allows to visit a container, abstracting from the shape of the
  // container. There are different kinds of iterators:
  //
  // input:         allows to read elements from a container
  // output:        allows to modify elements in a container
  // forward:       allows to walk container elements forward
  // bidirectional: allows to walk container elements in reverse order
  // random access: allows to access randomly to container elements
  //
  // Each kind of iterator is defined by a set of operations. Iterators are
  // ordered by complexity, thus an output iterator is an extension of an input
  // iterator.
  //
  // This iterator is an input iterator.
  class iterator {
  public:
    // All iterators must be copy-constructed.
    iterator(const iterator &it) : instrs(it.instrs), curInstr(it.curInstr) { }

    // All iterator must be copied using "operator=".
    const iterator operator=(const iterator &it) {
      // The check skip self-copy.
      if(&it != this) {
        instrs = it.instrs;
        curInstr = it.curInstr;
      }

      return *this;
    }

  private:
    // This is a private constructor used by the container class -- "Program" --
    // to build the iterator. We need a reference to a collection of
    // instructions and an instruction index.
    iterator(std::vector<Instruction *> &instrs, unsigned i) : instrs(instrs),
                                                               curInstr(i) { }

  public:
    // Input iterators requires iterators to be comparable using "operator=" ...
    bool operator==(iterator &it) {
      return instrs == it.instrs && curInstr == it.curInstr;
    }

    // ... and "operator!=". Please notice that "operator!=" is defined starting
    // from "operator==". This is a C++ idiom!
    bool operator!=(iterator &it) {
      return !(it == *this);
    }

    // All iterators support the pre-increment operator. The semantic of
    // pre-increment is clear: increment iterator, then return a reference to
    // the incremented iterator. Please notice that no new iterator is
    // constructed, thus pre-increment is more efficient than post-increment --
    // C++ performance thumb rule.
    iterator &operator++() {
      ++curInstr;
      return *this;
    }

    // All iterators support the post-increment operator. The member function
    // arguments is useless, it is only used by the compiler to differentiate
    // pre-increment an post-increment operators. The post-increment operator
    // semantic is: save iterator status before increment -- create a new
    // iterator -- increment this operator and return the new created iterator.
    // Please notice that this member function has been implemented using the
    // pre-increment operator -- C++ idiom.
    iterator operator++(int ign) {
      iterator old = *this;

      ++(*this);

      return old;
    }

    // Input iterators allows to access pointed element for reading. The
    // "operator*" has the same semantic provided for pointers. It allows to
    // access to the content of pointed data. Since this iterator points to
    // "Instruction", we must return a reference to an "Instruction".
    Instruction &operator*() {
      return *instrs[curInstr];
    }

    // This is another way to access pointed element. Please notice that a
    // pointer must be returned. The reason is that we want to be possible
    // writing this kind of expressions:
    //
    // i->memberFunction()
    //
    // where "memberFunction" is a memberFunction -- or field -- of pointed
    // object, "Instruction" in this case.
    Instruction *operator->() {
      return instrs[curInstr];
    }

  private:
    std::vector<Instruction *> &instrs;
    unsigned curInstr;

    // By declaring the "Program" class friend, we allows building iterators
    // by the container.
    friend class Program;
  };

public:
  // The "begin" member function is a C++ idiom. It is used to get an iterator
  // to the start of the container, even if the container is not ordered.
  iterator begin() { return iterator(instrs, 0); }

  // The "end" member function it is the dual of "begin". It allows to get the
  // end of the container. It must return an iterator pointing to an element
  // that is not part of the container.
  iterator end() { return iterator(instrs, instrs.size()); }

public:
  Program(std::vector<Instruction *> &instrs) : instrs(instrs) { }

public:
  size_t size() { return instrs.size(); }

private:
  std::vector<Instruction *> instrs;
};

class Compiler {
public:
  #define UNARY_INSTR(I)            \
  virtual Compiler &insert ## I() { \
    instrs.push_back(new I());      \
    return *this;                   \
  }

  #define TERNARY_INSTR(I)                                                  \
  virtual Compiler &insert ## I(Register out, Register inA, Register inB) { \
    instrs.push_back(new I(out, inA, inB));                                 \
    return *this;                                                           \
  }

  UNARY_INSTR(Halt)

  TERNARY_INSTR(Add)
  TERNARY_INSTR(Sub)
  TERNARY_INSTR(FFT)
  TERNARY_INSTR(Shuffle)

  #undef UNARY_INSTR
  #undef TERNARY_INSTR

  virtual Program build() {
    Program prog(instrs);

    instrs.clear();

    return prog;
  }

protected:
  std::vector<Instruction *> instrs;
};

class RISCCompiler : public Compiler {
public:
  #define TERNARY_INSTR(I)                                                  \
  virtual Compiler &insert ## I(Register out, Register inA, Register inB) { \
    instrs.push_back(new Trap());                                           \
    return *this;                                                           \
  }

  TERNARY_INSTR(FFT)
  TERNARY_INSTR(Shuffle)

  #undef TERNARY_INSTR
};

class CISCCompiler : public Compiler { };

class Processor {
public:
  static Register R0;
  static Register R1;
  static Register R2;
  static Register R3;

public:
  Processor(const char *name) : name(name) { }

public:
  virtual Processor &operator<<(Instruction &instr) = 0;

public:
  std::string &getName() { return name; }

  virtual Compiler &getCompiler() = 0;

protected:
  Processor &notImplemented(Instruction &instr) {
    std::cerr << getName() << ": "
              << instr.getName() << " not implemented"
              << std::endl;

    return *this;
  }

private:
  std::string name;
};

class RISCProcessor : public Processor {
private:
  static RISCCompiler compiler;

public:
  RISCProcessor(const char *name) : Processor(name) { }

  virtual Processor &operator<<(Instruction &instr) {
    #define INSTR(I)                          \
    if(I *casted = dynamic_cast<I *>(&instr)) \
      return operator<<(*casted);

    INSTR(Add)
    INSTR(Sub)
    INSTR(Trap)
    INSTR(Halt)

    #undef INSTR

    return notImplemented(instr);
  }

  virtual Compiler &getCompiler() { return compiler; }

  // This method is replicated for teaching purposes.
  void dump();

protected:
  Processor &operator<<(Add &add) {
    return dumpInstruction(add);
  }

  Processor &operator<<(Sub &sub) {
    return dumpInstruction(sub);
  }

  Processor &operator<<(Trap &trap) {
    return dumpInstruction(trap);
  }

  Processor &operator<<(Halt &halt) {
    return dumpInstruction(halt);
  }

  Processor &dumpInstruction(Instruction &instr) {
    std::cerr << getName() << ": " << instr.getName() << std::endl;

    return *this;
  }
};

std::ostream &operator<<(std::ostream &os, RISCProcessor &proc);

class DSPProcessor {
public:
  static Register X0;
  static Register X1;
  static Register X2;
  static Register X3;

public:
  DSPProcessor(Processor &master) : master(master) { }

protected:
  DSPProcessor &operator<<(FFT &fft) {
    return dumpInstruction(fft);
  }

  DSPProcessor &operator<<(Shuffle &shuffle) {
    return dumpInstruction(shuffle);
  }

private:
  DSPProcessor &dumpInstruction(Instruction &instr) {
    std::cerr << master.getName() << ": " << instr.getName() << std::endl;

    return *this;
  }

private:
  Processor &master;
};

class CISCProcessor : public RISCProcessor, public DSPProcessor {
private:
  static CISCCompiler compiler;

public:
  CISCProcessor(const char *name) :
    RISCProcessor(name),
    DSPProcessor(*static_cast<RISCProcessor *>(this)) { }

public:
  virtual Processor &operator<<(Instruction &instr) {
    #define INSTR(I)                            \
    if(I *casted = dynamic_cast<I *>(&instr)) { \
      RISCProcessor::operator<<(*casted);       \
      return *this;                             \
    }

    INSTR(Add)
    INSTR(Sub)
    INSTR(Trap)
    INSTR(Halt)

    #undef INSTR

    #define INSTR(I)                            \
    if(I *casted = dynamic_cast<I *>(&instr)) { \
      DSPProcessor::operator<<(*casted);        \
      return *this;                             \
    }

    INSTR(FFT)
    INSTR(Shuffle)

    #undef INSTR

    return notImplemented(instr);
  }

  virtual Compiler &getCompiler() { return compiler; }

  // This method is replicated for teaching purposes.
  void dump();
};

std::ostream &operator<<(std::ostream &os, CISCProcessor &proc);

void Simulate(Processor &proc);

} // End namespace plp.

using namespace plp;

Register Processor::R0("R0");
Register Processor::R1("R1");
Register Processor::R2("R1");
Register Processor::R3("R1");

Register DSPProcessor::X0("X0");
Register DSPProcessor::X1("X1");
Register DSPProcessor::X2("X1");
Register DSPProcessor::X3("X1");

RISCCompiler RISCProcessor::compiler;
CISCCompiler CISCProcessor::compiler;

void RISCProcessor::dump() {
  std::cerr << *this << std::endl;
}

std::ostream &plp::operator<<(std::ostream &os, RISCProcessor &proc) {
  os << "Size of " << proc.getName() << ": " << sizeof(RISCProcessor);

  return os;
}

void CISCProcessor::dump() {
  std::cerr << *this << std::endl;
}

std::ostream &plp::operator<<(std::ostream &os, CISCProcessor &proc) {
  os << "Size of " << proc.getName() << ": " << sizeof(CISCProcessor);

  return os;
}

int main(int argc, char *argv[]) {
  CISCProcessor p1("P1");
  RISCProcessor p2("P2");

  Simulate(p1);
  std::cout << std::endl;
  Simulate(p2);

  std::cout << std::endl << "Statistics" << std::endl;
  p1.dump();
  p2.dump();

  return EXIT_SUCCESS;
}

void plp::Simulate(Processor &proc) {
  std::cout << proc.getName() << " Simulation Start" << std::endl;

  Compiler &comp = proc.getCompiler();

  Program prog = comp.insertAdd(Processor::R1, Processor::R2, Processor::R3)
                     .insertSub(Processor::R3, Processor::R0, Processor::R1)
                     .insertFFT(DSPProcessor::X1,
                                DSPProcessor::X2,
                                DSPProcessor::X3)
                     .insertShuffle(DSPProcessor::X3,
                                    DSPProcessor::X1,
                                    DSPProcessor::X0)
                     .insertHalt()
                     .build();

  // Using an iterator we can access to program instructions without considering
  // how instructions are stored inside the program.
  for(Program::iterator i = prog.begin(), e = prog.end(); i != e; ++i)
    proc << *i;

  std::cout << proc.getName() << " Simulation End" << std::endl;
}
