
#include <iostream>
#include <string>

#include <cstdlib>

namespace plp {

class Root {
public:
  Root(const char *name) : name(name) { }

public:
  std::string &getName() { return name; }

private:
  std::string name;
};

class LeftChild : public Root {
public:
  LeftChild(const char *name) : Root(name) { }

public:
  std::string &getLeftName() { return getName(); }
};

class RightChild : public Root {
public:
  RightChild(const char *name) : Root(name) { }

public:
  std::string &getRightName() { return getName(); }
};

// Here we are joining two inheritance lines -- diamond problem! The C++
// approach to the problem is straightforward: ignore it! Compile errors can
// arise only when the C++ front-end cannot resolve the ambiguity.
class GrandChild : public LeftChild, public RightChild {
public:
  GrandChild() : LeftChild("Tom"), RightChild("Sawyer") { }

public:
  void dump();
};

std::ostream &operator<<(std::ostream &os, GrandChild &child);

} // End namespace plp.

using namespace plp;

void GrandChild::dump() {
  std::cerr << *this;
}

std::ostream &plp::operator<<(std::ostream &os, GrandChild &child) {
  os << "### GrandChild ###" << std::endl
     << "  sizeof(GrandChild) = " << sizeof(GrandChild) << std::endl
     << "  sizeof(LeftChild)  = " << sizeof(LeftChild)  << std::endl
     << "  sizeof(RightChild) = " << sizeof(RightChild) << std::endl
     << "  sizeof(Root)       = " << sizeof(Root)       << std::endl;

  return os;
}

int main(int argc, char *argv[]) {
  GrandChild leaf;

  // Here there is no ambiguity, because "get{Left,Right}Name" are defined in
  // different classes. Calling "getName" over "leaf" results in a compile-time
  // error -- the C++ front-end does not known whether to call "getName"
  // inherited from "LeftChild" of the one inherited from "RightChild".
  std::cout << "Hi, my left parent says I'm "
            << leaf.getLeftName() << std::endl;
  std::cout << "Hi, my right parent says I'm "
            << leaf.getRightName() << std::endl;

  leaf.dump();

  return EXIT_SUCCESS;
}
