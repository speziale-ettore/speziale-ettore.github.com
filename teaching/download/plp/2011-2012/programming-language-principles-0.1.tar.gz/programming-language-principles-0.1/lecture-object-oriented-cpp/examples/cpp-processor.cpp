
#include <iostream>
#include <string>

#include <cstdlib>

namespace plp {

// This is a root class! In Java classes are single-rooted -- java.lang.Object
// is the only root class. In C++, you can have as many root classes as you
// want.
class Register {
public:
  Register(const char *name) : name(name) { }

private:
  std::string name;
};

// Another root class -- no problems in C++.
class Instruction {
public:
  Instruction(const char *name) : name(name) { }

public:
  std::string &getName() { return name; }

private:
  std::string name;
};

// Single inheritance. In this case the inheritance mechanism works like in Java
// -- there are some minor differences on scopes. In C++ is it possible to
// change symbols visibility while deriving a class. The 'public' modifiers is
// equivalent to Java derivation mechanism.
class UnaryInstruction : public Instruction {
public:
  // Together with field initialization list you can call the constructor of the
  // superclass -- no fields to initialize here.
  UnaryInstruction(const char *name) : Instruction(name) { }
};

class TernaryInstruction : public Instruction {
public:
  // Together with field initialization list you can call the constructor of the
  // superclass -- superclass constructor must be called before fields
  // initialization.
  TernaryInstruction(Register out,
                     Register inA,
                     Register inB,
                     const char *name) :
    Instruction(name),
    out(out),
    inA(inA),
    inB(inB) { }

private:
  Register out;
  Register inA;
  Register inB;
};

class Add : public TernaryInstruction {
public:
  Add(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "add") { }
};

class Sub : public TernaryInstruction {
public:
  Sub(Register out, Register inA, Register inB) :
    TernaryInstruction(out, inA, inB, "sub") { }
};

class Halt : public UnaryInstruction {
public:
  Halt() : UnaryInstruction("halt") { }
};

class Processor {
public:
  // Static variables cannot be initialized here -- like in Java. See below.
  static Register R0;
  static Register R1;
  static Register R2;
  static Register R3;

public:
  Processor(const char *name) : name(name) { }

public:
  // In C++ virtual table layout is under the control of the programmer! By
  // putting the 'virtual' keyword in front of member function declaration we
  // force using dynamic binding for that function.
  virtual Processor &operator<<(Add &add) {
    return notImplemented(add);
  }

  virtual Processor &operator<<(Sub &sub) {
    return notImplemented(sub);
  }

  virtual Processor &operator<<(Halt &halt) {
    return notImplemented(halt);
  }

public:
  // Here there isn't the 'virtual' keyword. This member function is always
  // called directly -- without using the virtual table, like an ordinary C
  // function.
  std::string &getName() { return name; }

  // This method is replicated in both Processor and RISCProcessor for teaching
  // purposes.
  void dump();

protected:
  Processor &notImplemented(Instruction &instr) {
    std::cerr << name << ": "
              << instr.getName() << " not implemented"
              << std::endl;

    return *this;
  }

private:
  std::string name;
};

std::ostream &operator<<(std::ostream &os, Processor &proc);

class RISCProcessor : public Processor {
public:
  RISCProcessor(const char *name) : Processor(name) { }

  virtual Processor &operator<<(Add &add) {
    return dumpInstruction(add);
  }

  virtual Processor &operator<<(Sub &sub) {
    return dumpInstruction(sub);
  }

  virtual Processor &operator<<(Halt &halt) {
    return dumpInstruction(halt);
  }

  // This method is replicated in both Processor and RISCProcessor for teaching
  // purposes.
  void dump();

private:
  Processor &dumpInstruction(Instruction &instr) {
    std::cerr << getName() << ": " << instr.getName() << std::endl;

    return *this;
  }
};

std::ostream &operator<<(std::ostream &os, RISCProcessor &proc);

void Simulate(Processor &proc);

} // End namespace plp.

using namespace plp;

// Class static variables must be initialized in this way, so the compiler can
// reserve space in memory for the variables.
Register Processor::R0("R0");
Register Processor::R1("R1");
Register Processor::R2("R1");
Register Processor::R3("R1");

void Processor::dump() {
  std::cerr << *this << std::endl;
}

std::ostream &plp::operator<<(std::ostream &os, Processor &proc) {
  os << "Size of " << proc.getName() << ": " << sizeof(Processor);

  return os;
}

void RISCProcessor::dump() {
  std::cerr << *this << std::endl;
}

std::ostream &plp::operator<<(std::ostream &os, RISCProcessor &proc) {
  os << "Size of " << proc.getName() << ": " << sizeof(RISCProcessor);

  return os;
}

int main(int argc, char *argv[]) {
  Processor p1("P1");
  RISCProcessor p2("P2");

  Simulate(p1);
  std::cout << std::endl;
  Simulate(p2);

  std::cout << std::endl << "Statistics" << std::endl;
  p1.dump();
  p2.dump();

  return EXIT_SUCCESS;
}

void plp::Simulate(Processor &proc) {
  std::cout << proc.getName() << " Simulation Start" << std::endl;

  Add add(Processor::R1, Processor::R2, Processor::R3);
  Sub sub(Processor::R3, Processor::R0, Processor::R1);
  Halt halt;

  proc << add << sub << halt;

  std::cout << proc.getName() << " Simulation End" << std::endl;
}
