struct Baz {
  virtual void biz();
};
struct Foo: public Baz {
  virtual void bar();
  virtual void biz();
};
