class Big {
  char a;
  int b;
  char c;
};
