struct Cip {
  virtual void run();
};
struct Ciop: public Chip,
             public Foo { };
