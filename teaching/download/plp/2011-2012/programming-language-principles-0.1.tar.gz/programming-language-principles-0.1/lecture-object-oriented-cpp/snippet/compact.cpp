class Compact {
  char a;
  char c;
  int b;
};
