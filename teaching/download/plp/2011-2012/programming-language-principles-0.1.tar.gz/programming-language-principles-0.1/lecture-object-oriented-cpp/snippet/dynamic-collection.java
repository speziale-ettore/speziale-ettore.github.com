interface Collection {
  public boolean add(Object o);
  public boolean contains();
}

class LinkedList implements Collection {
  public boolean add(Object o) { ... }
  public boolean contains() { ... }
}

Collection coll = new LinkedList();
coll.add(new Object());
